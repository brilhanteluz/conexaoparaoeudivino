import Link from 'next/link'
import Image from 'next/image'
import { Flame, Sparkles, Heart } from 'lucide-react'

const LOGO = 'https://cdn.abacus.ai/images/221414c2-0d17-47d6-94bd-cc138ca9fcad.png'

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-background/70 backdrop-blur-sm">
      <div className="gold-divider" />
      <div className="mx-auto flex max-w-[1200px] flex-col items-center gap-6 px-6 py-12 text-center">
        <div className="relative h-20 w-20 overflow-hidden rounded-full shadow-lg">
          <Image src={LOGO} alt="Logo cósmica Conexão para o Eu Divino" fill className="object-cover" sizes="80px" />
        </div>
        <p className="max-w-xl font-display text-lg text-gold">
          “Eu Sou a Ressurreição e a Vida.”
        </p>
        <nav className="flex flex-wrap justify-center gap-2" aria-label="Links do rodapé">
          <Link href="/eu-sou" className="inline-flex items-center gap-2 rounded-md bg-secondary/20 px-4 py-2 text-sm text-foreground/85 hover:bg-secondary/40 hover:text-primary">
            <Sparkles className="h-4 w-4" /> Presença Eu Sou
          </Link>
          <Link href="/decretos" className="inline-flex items-center gap-2 rounded-md bg-secondary/20 px-4 py-2 text-sm text-foreground/85 hover:bg-secondary/40 hover:text-primary">
            <Flame className="h-4 w-4" /> Decretos
          </Link>
          <Link href="/comunidade" className="inline-flex items-center gap-2 rounded-md bg-secondary/20 px-4 py-2 text-sm text-foreground/85 hover:bg-secondary/40 hover:text-primary">
            <Heart className="h-4 w-4" /> Pedidos de Luz
          </Link>
          <Link href="/contato" className="inline-flex items-center gap-2 rounded-md bg-secondary/20 px-4 py-2 text-sm text-foreground/85 hover:bg-secondary/40 hover:text-primary">
            <Heart className="h-4 w-4" /> Sobre
          </Link>
        </nav>
        <p className="text-xs text-muted-foreground">
          © 2026 Conexão para o Eu Divino · Feito com amor, sabedoria e poder a serviço da Luz.
        </p>
      </div>
    </footer>
  )
}
