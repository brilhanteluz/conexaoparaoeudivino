export type DecreeCategory = 'chama-violeta' | 'protecao' | 'amor' | 'cura' | 'abundancia' | 'ascensao'

export interface Decree {
  id: string
  title: string
  category: DecreeCategory
  master: string
  text: string
}

export const DECREE_CATEGORIES: { id: DecreeCategory; label: string }[] = [
  { id: 'chama-violeta', label: 'Chama Violeta' },
  { id: 'protecao', label: 'Proteção' },
  { id: 'amor', label: 'Amor' },
  { id: 'cura', label: 'Cura' },
  { id: 'abundancia', label: 'Abundância' },
  { id: 'ascensao', label: 'Ascensão' },
]

export const DECREES: Decree[] = [
  // CHAMA VIOLETA
  {
    id: 'cv-1',
    title: 'Eu Sou um Ser de Fogo Violeta',
    category: 'chama-violeta',
    master: 'Saint Germain',
    text: 'Eu Sou um ser de fogo violeta,\nEu Sou a pureza que Deus deseja!\n\nMeu coração é um farol de fogo violeta,\nEu Sou a pureza que Deus deseja!\n\nMinha mente é um sol de fogo violeta,\nEu Sou a pureza que Deus deseja!\n\nMeu corpo é um templo de fogo violeta,\nEu Sou a pureza que Deus deseja!',
  },
  {
    id: 'cv-2',
    title: 'Transmutação de Todo Carma',
    category: 'chama-violeta',
    master: 'Saint Germain',
    text: 'Em nome da amada e poderosa Presença de Deus Eu Sou em mim, e do amado Saint Germain, eu invoco a Chama Violeta Consumidora!\n\nTransmuta agora toda causa e núcleo, todo registro e memória de erro humano — meu e de toda a humanidade — cometido desde o princípio dos tempos.\n\nSubstitui tudo pela Perfeição Divina que Eu Sou, Eu Sou, Eu Sou!\nAssim seja, amado Eu Sou!',
  },
  {
    id: 'cv-3',
    title: 'Chama Violeta no Lar',
    category: 'chama-violeta',
    master: 'Santa Ametista',
    text: 'Amada Presença Eu Sou, envolve meu lar em um pilar de Chama Violeta!\n\nQue cada parede, cada objeto e cada coração que aqui habita seja purificado, liberado e preenchido de paz.\n\nEu Sou a Chama Violeta que transforma toda discordância em harmonia,\ntoda tristeza em alegria, todo medo em confiança.\nEu Sou a Liberdade de Deus manifesta aqui e agora!',
  },
  {
    id: 'cv-4',
    title: 'Perdão Divino',
    category: 'chama-violeta',
    master: 'Kuan Yin',
    text: 'Eu Sou o perdão aqui atuando,\nlançando fora dúvidas e medos,\nlibertando os homens para sempre\ncom asas de vitória cósmica.\n\nEu Sou invocando com pleno poder\no perdão a toda hora;\na toda vida, em toda parte,\ninundo com a Graça que perdoa!',
  },
  // PROTEÇÃO
  {
    id: 'pr-1',
    title: 'Tubo de Luz',
    category: 'protecao',
    master: 'Presença Eu Sou',
    text: 'Amada e radiante Presença Eu Sou,\nenvolve-me agora em teu Tubo de Luz\nde Chama de Mestre Ascencionado,\ninvocável em nome de Deus.\n\nQue ele me mantenha livre\nde toda discordância enviada a mim.\n\nEu invoco o Fogo Violeta\npara que arda e transmute todo desejo,\npersistindo em nome da Liberdade,\naté que eu me una à Chama Violeta.',
  },
  {
    id: 'pr-2',
    title: 'Arcanjo Miguel, Vem!',
    category: 'protecao',
    master: 'Arcanjo Miguel',
    text: 'São Miguel à frente, São Miguel atrás,\nSão Miguel à direita, São Miguel à esquerda,\nSão Miguel acima, São Miguel abaixo,\nSão Miguel, São Miguel, aonde quer que eu vá!\n\nEu Sou o seu Amor protegendo aqui!\nEu Sou o seu Amor protegendo aqui!\nEu Sou o seu Amor protegendo aqui!',
  },
  {
    id: 'pr-3',
    title: 'Escudo de Chama Azul',
    category: 'protecao',
    master: 'El Morya',
    text: 'Em nome da Presença Eu Sou, amado El Morya, estabelece ao meu redor um escudo impenetrável de Chama Azul!\n\nEu Sou a Vontade de Deus que guarda meus pensamentos, sentimentos, palavras e ações.\nNenhuma energia inferior pode me tocar,\npois Eu Sou selado no Coração Azul de Deus,\nagora e para sempre!',
  },
  {
    id: 'pr-4',
    title: 'Proteção para Viagens',
    category: 'protecao',
    master: 'Arcanjo Miguel',
    text: 'Amado Arcanjo Miguel e tuas legiões de Chama Azul,\nguardai-me em cada caminho que eu percorrer hoje.\n\nEu Sou a Luz que vai adiante de mim,\nabrindo estradas seguras e harmoniosas.\nEu Sou a Proteção Divina em cada veículo, em cada passo,\ne chego em paz ao meu destino. Assim é!',
  },
  // AMOR
  {
    id: 'am-1',
    title: 'Eu Sou o Amor Divino',
    category: 'amor',
    master: 'Lady Nada',
    text: 'Eu Sou o Amor Divino fluindo do meu coração\npara toda vida, em toda parte!\n\nEu Sou o Amor que tudo compreende,\no Amor que tudo perdoa,\no Amor que tudo cura.\n\nPela Chama Rosa que arde em mim,\neu abençoo cada ser com quem me encontro hoje.',
  },
  {
    id: 'am-2',
    title: 'Chama Trina em Equilíbrio',
    category: 'amor',
    master: 'Presença Eu Sou',
    text: 'Amada Presença Eu Sou, expande a Chama Trina do meu coração!\n\nQue o Poder azul, a Sabedoria dourada e o Amor rosa\nestejam em perfeito equilíbrio em mim.\n\nEu Sou o Amor sem fraqueza,\na Sabedoria sem orgulho,\no Poder sem dominação.\nEu Sou a Chama Trina da Vida em ação!',
  },
  {
    id: 'am-3',
    title: 'Amor Crístico',
    category: 'amor',
    master: 'Jesus/Sananda',
    text: 'Amado Jesus, envolve-me em tua radiação de Amor Crístico.\n\nEu Sou a Luz do Cristo que brilha em meu coração,\niluminando cada sombra, dissolvendo cada mágoa.\n\nEu Sou o Caminho, a Verdade e a Vida em ação,\ne amo como Tu amas — incondicionalmente.',
  },
  {
    id: 'am-4',
    title: 'Harmonia nos Relacionamentos',
    category: 'amor',
    master: 'Paulo, o Veneziano',
    text: 'Eu Sou a Presença de Deus que harmoniza todos os meus relacionamentos!\n\nQue a Chama Rosa dissolva toda crítica, julgamento e ressentimento.\nEu vejo o Cristo em cada ser,\ne cada ser vê o Cristo em mim.\nEu Sou a Paz, o Respeito e o Amor Divino em cada encontro.',
  },
  // CURA
  {
    id: 'cu-1',
    title: 'Eu Sou a Perfeição Divina',
    category: 'cura',
    master: 'Hilarion',
    text: 'Eu Sou a Perfeição Divina manifesta em cada célula do meu corpo!\n\nEu Sou a Saúde perfeita,\nEu Sou a Energia inesgotável,\nEu Sou a Vitalidade eterna de Deus.\n\nAmado Hilarion, banha-me na Chama Verde da Cura\ne restaura em mim o Plano Divino original.',
  },
  {
    id: 'cu-2',
    title: 'Chama da Ressurreição',
    category: 'cura',
    master: 'Jesus/Sananda',
    text: 'Eu Sou a Ressurreição e a Vida\nde cada célula e átomo do meu ser!\n\nEu Sou a Ressurreição e a Vida\nda minha saúde perfeita!\n\nEu Sou a Ressurreição e a Vida\nda minha alegria, do meu propósito e da minha luz!\n\nAssim seja, pelo Poder do Cristo em mim!',
  },
  {
    id: 'cu-3',
    title: 'Cura das Emoções',
    category: 'cura',
    master: 'Mestra Maria',
    text: 'Amada Mãe Maria, derrama sobre mim o teu bálsamo de Luz.\n\nEu Sou a paz que acalma toda ansiedade,\nEu Sou a esperança que ilumina toda tristeza,\nEu Sou o amor que cura toda ferida da alma.\n\nEm teu Coração Imaculado, eu repouso e sou renovado.',
  },
  {
    id: 'cu-4',
    title: 'Luz Esmeralda da Verdade',
    category: 'cura',
    master: 'Hilarion',
    text: 'Eu Sou a Verdade que liberta!\n\nQue a Luz Esmeralda de Hilarion penetre minha mente e meu coração,\ndissolvendo toda ilusão, todo engano e toda crença limitante.\n\nEu Sou a Visão clara, a Mente iluminada\ne o Corpo curado pela Verdade Divina.',
  },
  // ABUNDÂNCIA
  {
    id: 'ab-1',
    title: 'Eu Sou a Opulência de Deus',
    category: 'abundancia',
    master: 'Presença Eu Sou',
    text: 'Eu Sou a Opulência de Deus em ação,\nmanifesta agora em minha vida e em meu mundo!\n\nEu Sou a Fonte inesgotável de todo bem,\ne tudo o que eu necessito para cumprir meu Plano Divino\nflui até mim em abundância, com alegria e gratidão.',
  },
  {
    id: 'ab-2',
    title: 'Provisão Divina',
    category: 'abundancia',
    master: 'Fortuna',
    text: 'Amada Deusa da Provisão, Fortuna,\nabre as comportas da Abundância Cósmica em minha vida!\n\nEu Sou a provisão sempre presente de dinheiro, oportunidades e bemêventurança.\nTudo o que recebo, uso a serviço da Luz,\ne a Luz multiplica tudo o que eu dou.',
  },
  {
    id: 'ab-3',
    title: 'Gratidão que Multiplica',
    category: 'abundancia',
    master: 'Saint Germain',
    text: 'Eu Sou a Gratidão viva por todas as bênçãos que já recebi!\n\nEu Sou a Gratidão que abre as portas do Coração de Deus,\ne a Gratidão que multiplica o bem em mil vezes.\nObrigado, amada Presença Eu Sou, por tua abundância infinita!',
  },
  {
    id: 'ab-4',
    title: 'Precipitação do Bem',
    category: 'abundancia',
    master: 'Saint Germain',
    text: 'Em nome da Presença Eu Sou, eu decreto:\n\nEu Sou a Lei do Perdão e a Chama Violeta que libera todo bloqueio à minha abundância!\nEu Sou o Ouro Espiritual que se precipita em minha vida\ncomo prosperidade, saúde, harmonia e serviço.\nEu aceito isto feito agora, com pleno poder!',
  },
  // ASCENSÃO
  {
    id: 'as-1',
    title: 'Eu Sou a Chama da Ascensão',
    category: 'ascensao',
    master: 'Serapis Bey',
    text: 'Eu Sou a Chama da Ascensão\nque arde em mim e ao meu redor!\n\nEu Sou a Pureza, a Disciplina e a Luz\nque eleva cada célula do meu ser.\n\nAmado Serapis Bey, guia-me pelos degraus do Templo de Luxor,\naté que eu seja uno com minha Presença Eu Sou.',
  },
  {
    id: 'as-2',
    title: 'Eu Sou a Luz',
    category: 'ascensao',
    master: 'Presença Eu Sou',
    text: 'Eu Sou Luz, Luz radiante,\nLuz que irradia, Luz intensa.\nDeus consome minhas trevas\ntransmutando-as em Luz.\n\nHoje Eu Sou um foco do Sol Central.\nAtravés de mim flui um rio cristalino,\numa fonte viva de Luz\nque jamais pode ser qualificada\npor pensamentos e sentimentos humanos.\nEu Sou um posto avançado do Divino!',
  },
  {
    id: 'as-3',
    title: 'União com o Santo Ser Crístico',
    category: 'ascensao',
    master: 'Santo Ser Crístico',
    text: 'Amado Santo Ser Crístico, mediador entre minha Presença Eu Sou e meu ser exterior,\ntoma posse de mim agora!\n\nGoverna meus pensamentos, sentimentos, palavras e ações.\nEu Sou o Cristo em ação no mundo da forma,\ne caminho em direção à Luz a cada respiração.',
  },
  {
    id: 'as-4',
    title: 'Pureza e Disciplina',
    category: 'ascensao',
    master: 'Serapis Bey',
    text: 'Eu Sou a Chama Branca da Pureza em meus pensamentos!\nEu Sou a Chama Branca da Pureza em meus sentimentos!\nEu Sou a Chama Branca da Pureza em minhas palavras!\nEu Sou a Chama Branca da Pureza em minhas ações!\n\nCom alegria, eu aceito a disciplina do caminho,\npois ela me conduz à Liberdade eterna.',
  },
  // ORAÇÕES DO SITE ORIGINAL
  {
    id: 'or-1',
    title: 'Oração do Elemental do Corpo',
    category: 'protecao',
    master: 'Presença Eu Sou',
    text: 'Amada e poderosa Presença Eu Sou,\namado Cristo interno,\nvós que sois a minha vida,\na minha luz e a minha força,\nvos peço que enviais vossa Presença radiante\ne a Presença dos Seres de Luz\npara habitar em mim e neste lugar.\n\nQue o Elemental do meu corpo\nseja purificado, fortalecido e liberado\npara cumprir o Plano Divino\nde saúde, vitalidade e perfeição.\n\nEu aceito esta graça agora manifesta!\nAssim é, assim é, assim é!',
  },
  {
    id: 'or-2',
    title: 'Oração de São Miguel Arcanjo — 21 Dias de Limpeza',
    category: 'protecao',
    master: 'Arcanjo Miguel',
    text: 'Amado São Miguel Arcanjo,\nenviai vossas legiões de Luz\npara limpar, purificar e proteger\nmeu ser em todos os planos.\n\nNo nome do Cristo em mim,\nvos peço que acalmeis todos os meus medos\ne que o Cristo remova de mim\ntodo mecanismo de controle externo\nque me impede de expressar\na plenitude do meu Eu Divino.\n\nQue vossa espada de Luz Azul\ncorte todos os laços de discordância\ne que vosso escudo de fé\nme guarde neste caminhar de 21 dias\nde limpeza, cura e proteção.\n\nEu Sou a Liberdade de Deus manifesta!\nAssim é, assim é, assim é!',
  },
]

export interface FundamentalDecree {
  ray: string
  flame: string
  color: string
  text: string
}

export const FUNDAMENTAL_DECREES: FundamentalDecree[] = [
  { ray: '1º Raio', flame: 'Chama Azul', color: '#3B82F6', text: 'Eu Sou a Vontade de Deus em ação, guiando cada passo meu com Fé, Proteção e Poder Divino.' },
  { ray: '2º Raio', flame: 'Chama Dourada', color: '#FFD700', text: 'Eu Sou a Sabedoria e a Iluminação de Deus, a Mente de Cristo que tudo compreende.' },
  { ray: '3º Raio', flame: 'Chama Rosa', color: '#F472B6', text: 'Eu Sou o Amor Divino que tudo abraça, tudo perdoa e tudo harmoniza.' },
  { ray: '4º Raio', flame: 'Chama Branca', color: '#F8FAFC', text: 'Eu Sou a Pureza e a Ascensão, a Luz imaculada que me eleva à minha Presença.' },
  { ray: '5º Raio', flame: 'Chama Verde', color: '#22C55E', text: 'Eu Sou a Verdade e a Cura, a Perfeição Divina manifesta em meu corpo e em minha vida.' },
  { ray: '6º Raio', flame: 'Chama Rubi-Dourada', color: '#E11D48', text: 'Eu Sou a Paz, a Providência e o Serviço devocional a toda a vida.' },
  { ray: '7º Raio', flame: 'Chama Violeta', color: '#A855F7', text: 'Eu Sou a Chama Violeta da Liberdade, transmutando tudo o que não é Luz em Perfeição.' },
]
