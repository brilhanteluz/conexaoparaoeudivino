export interface DailyDecree {
  title: string
  text: string
}

export const DAILY_DECREES: DailyDecree[] = [
  { title: 'Presença Vitoriosa', text: 'Eu Sou a Presença de Deus vitoriosa em cada instante deste dia. Nada pode se opor à Luz que Eu Sou!' },
  { title: 'Liberdade Violeta', text: 'Eu Sou a Chama Violeta que transmuta todo erro em perfeição. Eu Sou livre, Eu Sou livre, Eu Sou livre em Deus!' },
  { title: 'Paz Interior', text: 'Eu Sou a Paz de Deus que ultrapassa todo entendimento, ancorada em meu coração e irradiada ao mundo.' },
  { title: 'Vontade Divina', text: 'Eu Sou a Vontade de Deus em ação. Que não seja feita a minha vontade humana, mas a Tua, amada Presença!' },
  { title: 'Iluminação', text: 'Eu Sou a Mente de Deus pensando através de mim. Eu Sou a Sabedoria que ilumina toda escolha.' },
  { title: 'Amor Incondicional', text: 'Eu Sou o Amor Divino fluindo para toda vida. Eu abençoo, eu perdoo, eu liberto.' },
  { title: 'Pureza', text: 'Eu Sou a Chama Branca da Pureza em cada pensamento, sentimento, palavra e ação.' },
  { title: 'Cura Perfeita', text: 'Eu Sou a Saúde perfeita de Deus manifesta em cada célula do meu corpo, agora e sempre.' },
  { title: 'Serviço Amoroso', text: 'Eu Sou as mãos, os pés e o coração de Deus a serviço da humanidade.' },
  { title: 'Abundância', text: 'Eu Sou a Opulência de Deus. Tudo o que necessito flui até mim com harmonia e gratidão.' },
  { title: 'Proteção Azul', text: 'Eu Sou envolto no Tubo de Luz e na Chama Azul do Arcanjo Miguel. Eu Sou invencível na Luz!' },
  { title: 'Ressurreição', text: 'Eu Sou a Ressurreição e a Vida de todo bem em minha vida. O que parecia perdido renasce em Luz.' },
  { title: 'Gratidão', text: 'Eu Sou a Gratidão viva por cada respiração, cada encontro e cada lição deste dia.' },
  { title: 'Chama Trina', text: 'Eu Sou o Amor, a Sabedoria e o Poder em perfeito equilíbrio no altar do meu coração.' },
  { title: 'Verdade', text: 'Eu Sou a Verdade que liberta. Toda ilusão se dissolve diante da Luz que Eu Sou.' },
  { title: 'Alegria', text: 'Eu Sou a Alegria de Deus cantando em meu ser. Minha vida é uma celebração da Luz!' },
  { title: 'Perdão', text: 'Eu Sou o Perdão que liberta a mim e a todos. Pela Chama Violeta, eu solto o passado com amor.' },
  { title: 'Harmonia', text: 'Eu Sou a Harmonia Divina em meu lar, em meu trabalho e em todos os meus relacionamentos.' },
  { title: 'Fé', text: 'Eu Sou a Fé inabalável no Plano Divino. Tudo coopera para o bem de quem ama a Luz.' },
  { title: 'Ascensão', text: 'Eu Sou a Chama da Ascensão que me eleva, degrau a degrau, à união com minha Presença Eu Sou.' },
  { title: 'Discernimento', text: 'Eu Sou a Visão clara do Olho Onividente de Deus. Eu vejo como Deus vê.' },
  { title: 'Compaixão', text: 'Eu Sou a Misericórdia e a Compaixão de Kuan Yin fluindo para todos os que sofrem.' },
  { title: 'Coragem', text: 'Eu Sou a Coragem do Cristo. Enfrento cada desafio sabendo que Deus caminha comigo.' },
  { title: 'Silêncio Sagrado', text: 'Eu Sou o Silêncio onde a Voz de Deus se faz ouvir. Na quietude, Eu Sou.' },
  { title: 'Unidade', text: 'Eu Sou uno com toda a vida. O Deus em mim saúda o Deus em cada ser.' },
  { title: 'Precipitação', text: 'Eu Sou a Lei da Precipitação em ação: o Bem Divino se manifesta agora em minha vida.' },
  { title: 'Luz Dourada', text: 'Eu Sou o Sol Dourado da Iluminação brilhando em minha mente e em toda a Terra.' },
  { title: 'Renovação', text: 'Eu Sou a Vida eterna que se renova a cada amanhecer. Hoje eu recomeço em Luz.' },
  { title: 'Consciência Crística', text: 'Eu Sou o Cristo em ação. Meu Santo Ser Crístico governa todos os meus caminhos.' },
  { title: 'Eu Sou o Que Eu Sou', text: 'Eu Sou o Que Eu Sou. Eu Sou a Luz, Eu Sou o Caminho, Eu Sou a Vitória de Deus manifesta!' },
]

export interface MasterMessage {
  master: string
  text: string
}

export const MASTER_MESSAGES: MasterMessage[] = [
  { master: 'Saint Germain', text: 'A Chama Violeta é o maior presente desta era. Usa-a todos os dias, e verás o impossível se tornar natural.' },
  { master: 'El Morya', text: 'A Vontade de Deus não é um fardo, amado. É o caminho mais curto para a tua felicidade.' },
  { master: 'Kuthumi', text: 'Quando a mente silencia, a Sabedoria que sempre esteve em ti começa a falar.' },
  { master: 'Lady Nada', text: 'Serve com amor, e o serviço se tornará a tua mais alta forma de oração.' },
  { master: 'Serapis Bey', text: 'A disciplina é o cinzel com o qual esculpes a tua ascensão. Aceita-a com alegria.' },
  { master: 'Hilarion', text: 'A Verdade cura. Tudo aquilo que reconheces com honestidade perde o poder de te ferir.' },
  { master: 'Jesus/Sananda', text: 'O Reino de Deus está dentro de vós. Não o procureis fora; ele sempre esteve no vosso coração.' },
  { master: 'Afra', text: 'Irmãos, a unidade não apaga as diferenças — ela as transforma em harmonia.' },
  { master: 'Mãe Maria', text: 'Coloca tuas dores no meu coração, e eu as devolverei a ti como rosas de luz.' },
  { master: 'Kuan Yin', text: 'A misericórdia que ofereces aos outros é a mesma que abre as portas da tua própria liberdade.' },
  { master: 'Arcanjo Miguel', text: 'Nunca estás só. Chama o meu nome e minhas legiões de Luz estarão contigo num instante.' },
  { master: 'Saint Germain', text: 'Cada “Eu Sou” que pronuncias cria o teu mundo. Escolhe tuas palavras como quem planta um jardim.' },
  { master: 'El Morya', text: 'Um coração dedicado vale mais que mil intenções. Começa hoje, com o que tens.' },
  { master: 'Kuthumi', text: 'Olha a natureza: ela não se apressa, e ainda assim tudo se realiza. Assim é também o teu caminho.' },
  { master: 'Lady Nada', text: 'O amor verdadeiro não exige — ele irradia. Torna-te um sol, e não um espelho.' },
  { master: 'Serapis Bey', text: 'A pureza não é ausência de erro, mas a decisão renovada de voltar sempre à Luz.' },
  { master: 'Hilarion', text: 'Tua célula ouve teus pensamentos. Pensa saúde, sente saúde, decreta saúde.' },
  { master: 'Jesus/Sananda', text: 'As obras que eu fiz, vós também as fareis — e maiores ainda, pois o mesmo Cristo habita em vós.' },
  { master: 'Paulo, o Veneziano', text: 'A beleza é a assinatura de Deus. Cultiva-a em tua vida e ela te conduzirá ao Amor.' },
  { master: 'Presença Eu Sou', text: 'Eu estou sempre contigo. Volta teu olhar para cima e sente o meu raio de Luz em teu coração.' },
  { master: 'Saint Germain', text: 'A liberdade começa no instante em que perdoas. Perdoa, e as correntes caem sozinhas.' },
  { master: 'El Morya', text: 'Fé é agir antes de ver. Confia no Plano Divino, pois ele é perfeito.' },
  { master: 'Kuthumi', text: 'Estuda, medita e serve. Esses três pilares sustentam o templo da iluminação.' },
  { master: 'Lady Nada', text: 'Fala com doçura. Uma palavra amorosa pode curar o que anos de silêncio feriram.' },
  { master: 'Serapis Bey', text: 'Cada pequena vitória sobre o ego é um degrau da escada que te leva à Luz.' },
  { master: 'Hilarion', text: 'Busca a Verdade com mente aberta e coração humilde; ela virá ao teu encontro.' },
  { master: 'Jesus/Sananda', text: 'Amai-vos uns aos outros. Esta é a Lei que contém todas as leis.' },
  { master: 'Afra', text: 'Quando um irmão se eleva, toda a humanidade se eleva com ele.' },
  { master: 'Saint Germain', text: 'A Idade de Ouro não é um sonho distante — ela nasce em cada coração que escolhe a Luz hoje.' },
  { master: 'Presença Eu Sou', text: 'Tu és o que Eu Sou. Lembra-te disto, e nada mais te faltará.' },
]

export function dayIndex(len: number): number {
  const safeLen = len > 0 ? len : 1
  return Math.floor(Date.now() / 86400000) % safeLen
}
