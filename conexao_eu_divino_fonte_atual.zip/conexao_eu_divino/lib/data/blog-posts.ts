export type BlogCategory = 'Ensinamentos' | 'Mensagens Canalizadas' | 'Práticas' | 'Reflexões'

export interface BlogBlock {
  type: 'p' | 'h2' | 'quote'
  text: string
}

export interface BlogPost {
  slug: string
  title: string
  excerpt: string
  category: BlogCategory
  author: string
  date: string
  readTime: string
  image: string
  content: BlogBlock[]
}

export const BLOG_CATEGORIES: BlogCategory[] = ['Ensinamentos', 'Mensagens Canalizadas', 'Práticas', 'Reflexões']

export const BLOG_POSTS: BlogPost[] = [
  {
    slug: 'o-que-e-a-divina-presenca-eu-sou',
    title: 'O Que é a Divina Presença Eu Sou?',
    excerpt: 'Conheça o ensinamento central da Grande Fraternidade Branca: a centelha de Deus individualizada que habita acima e dentro de cada ser humano.',
    category: 'Ensinamentos',
    author: 'Equipe Conexão para o Eu Divino',
    date: '2026-09-20',
    readTime: '7 min',
    image: 'https://cdn.abacus.ai/images/75cead93-ae73-4f54-afe7-96e7a8b02261.png',
    content: [
      { type: 'p', text: 'Quando Moisés perguntou a Deus diante da sarça ardente qual era o Seu nome, a resposta foi: “EU SOU O QUE EU SOU”. Este nome sagrado atravessou os séculos e, nos ensinamentos dos Mestres Ascencionados, revela-se como a chave para compreender quem realmente somos.' },
      { type: 'h2', text: 'Deus individualizado em você' },
      { type: 'p', text: 'A Divina Presença Eu Sou é a individualização de Deus para cada alma. Não é um ser externo ou distante: é o seu Eu Real, perfeito e eterno, que nunca foi tocado por nenhuma imperfeição humana. Ela reside em uma dimensão de luz pura, logo acima de você, e está ligada ao seu coração por um fio de luz chamado Cordão de Cristal.' },
      { type: 'p', text: 'Ao redor da Presença Eu Sou, os ensinamentos descrevem o Corpo Causal: esferas concêntricas de luz colorida onde estão guardados todos os bons pensamentos, sentimentos e ações que você já realizou, em todas as suas vidas. Esse é o seu verdadeiro tesouro no céu.' },
      { type: 'h2', text: 'As três partes do ser' },
      { type: 'p', text: 'O conhecido “Diagrama da Presença Eu Sou” apresenta três figuras. No alto, a Presença Eu Sou, fonte de toda vida. No meio, o Santo Ser Crístico — o mediador, o Cristo interior que traduz a luz divina para a nossa consciência. Embaixo, a personalidade humana, envolta em Chama Violeta e protegida por um Tubo de Luz.' },
      { type: 'quote', text: 'Tu não és o corpo, nem a mente, nem as emoções. Tu és a Presença de Deus usando estes veículos para se expressar no mundo da forma.' },
      { type: 'h2', text: 'Por que isso muda tudo' },
      { type: 'p', text: 'Compreender a Presença Eu Sou transforma a espiritualidade de uma busca externa em um reencontro interior. Cada vez que você diz “eu sou”, está usando o nome de Deus e qualificando a energia divina que flui por você. Por isso os Mestres nos pedem atenção: “eu sou cansado”, “eu sou incapaz” são decretos tão poderosos quanto “eu sou a luz”.' },
      { type: 'p', text: 'O caminho proposto pela Grande Fraternidade Branca é o da reunificação gradual com essa Presença, até a ascensão — o momento em que a alma se funde completamente com sua fonte divina. Esse caminho começa hoje, com a simples decisão de reconhecer: “Eu Sou o Que Eu Sou”.' },
    ],
  },
  {
    slug: 'chama-violeta-fogo-sagrado-da-transmutacao',
    title: 'Chama Violeta: o Fogo Sagrado da Transmutação',
    excerpt: 'Um guia prático para começar a usar a Chama Violeta no dia a dia e experimentar a libertação de padrões antigos.',
    category: 'Práticas',
    author: 'Equipe Conexão para o Eu Divino',
    date: '2026-09-15',
    readTime: '6 min',
    image: 'https://cdn.abacus.ai/images/706b9641-a918-4462-8c81-a1297ece16cf.png',
    content: [
      { type: 'p', text: 'De todas as dádivas oferecidas pelos Mestres Ascencionados à humanidade, talvez nenhuma seja tão prática e transformadora quanto a Chama Violeta. Liberada ao mundo através de Saint Germain, ela é descrita como a energia espiritual do Sétimo Raio: o raio da liberdade, da misericórdia e da transmutação.' },
      { type: 'h2', text: 'O que a Chama Violeta faz' },
      { type: 'p', text: 'Toda energia que usamos de forma desarmônica — em pensamentos de raiva, palavras duras ou ações egoístas — fica registrada em nosso campo energético. A Chama Violeta atua como um solvente espiritual: ela não destrói essa energia, mas a devolve ao seu estado original de pureza. É a verdadeira alquimia.' },
      { type: 'h2', text: 'Como começar' },
      { type: 'p', text: 'Reserve de 5 a 15 minutos por dia. Sente-se em silêncio, conecte-se com sua Presença Eu Sou e visualize-se envolto em chamas violetas que sobem dos pés à cabeça. Então, pronuncie em voz alta um decreto simples, como “Eu Sou um ser de Fogo Violeta, Eu Sou a pureza que Deus deseja”, repetindo-o ritmicamente.' },
      { type: 'p', text: 'A voz é importante. A palavra falada carrega a energia do chakra laríngeo e ancora a luz no plano físico. Se não puder falar em voz alta, sussurre ou decrete mentalmente, mas sempre com sentimento.' },
      { type: 'quote', text: 'Use a Chama Violeta todos os dias, e em pouco tempo verás que problemas que pareciam impossíveis se dissolvem como a névoa ao sol da manhã. — Saint Germain' },
      { type: 'h2', text: 'Sinais de que está funcionando' },
      { type: 'p', text: 'Muitos praticantes relatam uma sensação de leveza, maior facilidade para perdoar, sonhos reveladores e situações antigas se resolvendo de modo inesperado. Seja paciente: a transmutação é cumulativa. Cada decreto soma luz ao seu mundo.' },
    ],
  },
  {
    slug: 'mensagem-de-saint-germain-para-a-nova-era',
    title: 'Mensagem de Saint Germain para a Nova Era',
    excerpt: 'Uma mensagem inspirada no amor do Mestre da Chama Violeta sobre a Idade de Ouro que nasce no coração de cada pessoa.',
    category: 'Mensagens Canalizadas',
    author: 'Inspirada pelo Mestre Saint Germain',
    date: '2026-09-08',
    readTime: '5 min',
    image: 'https://cdn.abacus.ai/images/574254e5-7405-4b11-b929-349621db1935.png',
    content: [
      { type: 'p', text: 'Amados filhos da Luz, eu vos saúdo na Chama da Liberdade. Venho neste momento em que a Terra atravessa um portal de grande transformação, para lembrar-vos de que não estais sozinhos e de que cada um de vós é necessário.' },
      { type: 'p', text: 'Muitos olham ao redor e veem conflitos, incertezas e mudanças rápidas. Eu vos digo: aquilo que está vindo à superfície está vindo para ser transmutado. Não temais a sombra que se revela; temei apenas esquecer a Luz que Eu Sou em vós.' },
      { type: 'h2', text: 'A Idade de Ouro começa em vós' },
      { type: 'p', text: 'A Idade de Ouro de Aquário não chegará por decreto de governos, nem por descobertas da ciência apenas. Ela nascerá, primeiro, em cada coração que escolher a liberdade, o perdão e o amor. Cada vez que perdoais, uma pedra é colocada no alicerce desse novo tempo.' },
      { type: 'quote', text: 'Não espereis o mundo mudar para então mudardes. Sede vós a Chama Violeta que o mundo espera.' },
      { type: 'p', text: 'Eu vos peço: dedicai alguns minutos por dia à Chama Violeta. Não apenas para vós, mas pela Terra, pelos elementais, pelas crianças e por aqueles que não sabem orar. Vossa voz unida é mais poderosa do que imaginais.' },
      { type: 'p', text: 'Eu estou convosco. Meu coração está unido ao vosso. E na hora em que me chamardes, ali estarei, envolvendo-vos em meu manto violeta. Eu Sou Saint Germain, e vos selo na Liberdade de Deus.' },
    ],
  },
  {
    slug: 'os-sete-raios-e-a-jornada-da-alma',
    title: 'Os Sete Raios e a Jornada da Alma',
    excerpt: 'Entenda como as sete emanações da Luz Divina formam o caminho de aprendizado da alma e quais Mestres guardam cada uma delas.',
    category: 'Ensinamentos',
    author: 'Equipe Conexão para o Eu Divino',
    date: '2026-08-30',
    readTime: '8 min',
    image: 'https://cdn.abacus.ai/images/d910d47d-016a-4ff2-8aba-692b34d89afa.png',
    content: [
      { type: 'p', text: 'Assim como a luz branca, ao atravessar um prisma, se decompõe em sete cores, a Luz de Deus se manifesta em sete raios, cada um com qualidades específicas. Nos ensinamentos da Grande Fraternidade Branca, esses raios são os caminhos pelos quais a alma desenvolve suas virtudes divinas.' },
      { type: 'h2', text: 'As sete emanações' },
      { type: 'p', text: '1º Raio — Azul: a Vontade de Deus, a fé e a proteção, sob a direção de El Morya. 2º Raio — Dourado: a sabedoria e a iluminação, guardado por Lanto e ligado a Kuthumi. 3º Raio — Rosa: o amor divino, com Paulo, o Veneziano. 4º Raio — Branco: a pureza e a ascensão, com Serapis Bey.' },
      { type: 'p', text: '5º Raio — Verde: a verdade, a cura e a ciência, com Hilarion. 6º Raio — Rubi-Dourado: a paz, o serviço e a devoção, com Lady Nada. 7º Raio — Violeta: a liberdade, a transmutação e o ritual, com Saint Germain.' },
      { type: 'quote', text: 'Cada raio é uma porta. Todas conduzem ao mesmo templo: a união com a Presença Eu Sou.' },
      { type: 'h2', text: 'Encontrando seu raio' },
      { type: 'p', text: 'Todos nós trabalhamos com os sete raios ao longo das encarnações, mas é comum sentir maior afinidade com um ou dois deles em determinada fase da vida. Observe quais virtudes você mais deseja desenvolver, quais cores o atraem e quais Mestres tocam seu coração.' },
      { type: 'p', text: 'Uma prática simples é dedicar cada dia da semana a um raio: domingo ao dourado, segunda ao rosa, terça ao azul, quarta ao verde, quinta ao rubi-dourado, sexta ao branco e sábado ao violeta. Assim, a alma se equilibra e se fortalece em todas as virtudes.' },
    ],
  },
  {
    slug: 'o-poder-da-palavra-falada-como-decretar',
    title: 'O Poder da Palavra Falada: Como Decretar',
    excerpt: 'Por que os decretos do Eu Sou são tão poderosos e como praticá-los com consciência, ritmo e sentimento.',
    category: 'Práticas',
    author: 'Equipe Conexão para o Eu Divino',
    date: '2026-08-22',
    readTime: '6 min',
    image: 'https://cdn.abacus.ai/images/f1caa455-8281-4294-9ed3-1d8b5a5cde34.png',
    content: [
      { type: 'p', text: '“No princípio era o Verbo.” A palavra falada é a força criadora do universo. Nos ensinamentos dos Mestres Ascencionados, o decreto é a forma mais dinâmica de oração: uma afirmação de autoridade divina que comanda a energia de Deus a se manifestar.' },
      { type: 'h2', text: 'Oração, afirmação e decreto' },
      { type: 'p', text: 'Na oração tradicional, pedimos. Na afirmação, reconhecemos uma verdade. No decreto, nós nos unimos à Presença Eu Sou e, em seu nome, ordenamos que a luz atue. Não é arrogância: é o reconhecimento de que o poder vem de Deus em nós.' },
      { type: 'h2', text: 'Estrutura de um decreto' },
      { type: 'p', text: 'Um decreto completo costuma ter três partes: o preâmbulo, em que invocamos a Presença Eu Sou e os Mestres; o corpo, com as afirmações e pedidos; e o fechamento, em que aceitamos o resultado como já manifestado — “Assim seja, amado Eu Sou!”' },
      { type: 'quote', text: 'Decreta com amor, visualiza com clareza e sente com o coração. Estes três unidos tornam tua palavra irresistível.' },
      { type: 'h2', text: 'Dicas para a prática' },
      { type: 'p', text: 'Fale em voz alta, com firmeza e ritmo. Repita cada decreto três, nove ou mais vezes. Mantenha a coluna ereta e visualize a luz atuando enquanto decreta. Comece com poucos minutos e aumente gradualmente. E, acima de tudo, mantenha o coração cheio de gratidão: ela abre as portas para que a luz flua sem obstáculos.' },
      { type: 'p', text: 'Na página de Decretos deste site você encontra dezenas de decretos organizados por tema, com contador pessoal para acompanhar sua prática.' },
    ],
  },
  {
    slug: 'silencio-interior-reflexoes-sobre-a-ascensao',
    title: 'Silêncio Interior: Reflexões sobre a Ascensão',
    excerpt: 'Em meio à pressa do mundo, o silêncio é o templo onde a alma reencontra sua Presença e percebe que a ascensão começa agora.',
    category: 'Reflexões',
    author: 'Equipe Conexão para o Eu Divino',
    date: '2026-08-14',
    readTime: '5 min',
    image: 'https://images.pexels.com/photos/1421898/pexels-photo-1421898.jpeg?auto=compress&cs=tinysrgb&w=1600',
    content: [
      { type: 'p', text: 'Vivemos cercados de ruído: notificações, conversas, pensamentos que não param. E, no entanto, todas as tradições espirituais concordam que Deus fala no silêncio. “Aquieta-te e sabe que Eu Sou Deus”, diz o Salmo.' },
      { type: 'h2', text: 'A ascensão não é fuga' },
      { type: 'p', text: 'Muitas vezes imaginamos a ascensão como um evento distante e extraordinário. Mas Serapis Bey ensina que ela é construída diariamente, nas pequenas escolhas: responder com paciência em vez de irritação, escolher a gratidão em vez da reclamação, voltar à Presença em vez de se perder no medo.' },
      { type: 'quote', text: 'A ascensão é o retorno consciente à casa do Pai. E toda casa tem uma porta: o silêncio do coração.' },
      { type: 'h2', text: 'Cultivando o silêncio' },
      { type: 'p', text: 'Experimente começar o dia com cinco minutos de silêncio antes de pegar o celular. Apenas respire e sinta sua Chama Trina. Ao longo do dia, faça pequenas pausas para dizer internamente “Eu Sou” e perceber-se presente.' },
      { type: 'p', text: 'À noite, antes de dormir, revise seu dia com amor, envolva tudo na Chama Violeta e peça para ser levado aos retiros etéricos dos Mestres durante o sono. Aos poucos, o silêncio deixa de ser ausência de som e passa a ser presença de Deus.' },
      { type: 'p', text: 'Nesse silêncio, percebemos que nunca estivemos separados. A Presença Eu Sou sempre esteve aqui, esperando apenas que parássemos para ouvi-la.' },
    ],
  },
]

export function getPost(slug: string): BlogPost | undefined {
  return BLOG_POSTS.find((p: BlogPost) => p?.slug === slug)
}
