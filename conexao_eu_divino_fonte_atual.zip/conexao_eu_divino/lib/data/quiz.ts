export interface QuizOption {
  text: string
  masters: string[]
}

export interface QuizQuestion {
  question: string
  options: QuizOption[]
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    question: 'Quando você enfrenta um problema difícil, qual é sua primeira reação?',
    options: [
      { text: 'Tomo uma decisão firme e ajo com coragem.', masters: ['el-morya'] },
      { text: 'Busco compreender a situação profundamente antes de agir.', masters: ['kuthumi', 'hilarion'] },
      { text: 'Procuro transformar a situação, perdoando e soltando o passado.', masters: ['saint-germain'] },
      { text: 'Penso em como as pessoas envolvidas estão se sentindo.', masters: ['lady-nada', 'jesus-sananda'] },
    ],
  },
  {
    question: 'Qual destas virtudes você mais deseja desenvolver?',
    options: [
      { text: 'Liberdade interior e leveza.', masters: ['saint-germain'] },
      { text: 'Disciplina e pureza de propósito.', masters: ['serapis-bey'] },
      { text: 'Amor incondicional.', masters: ['jesus-sananda', 'lady-nada'] },
      { text: 'Senso de pertencimento e união com todos.', masters: ['afra'] },
    ],
  },
  {
    question: 'Em qual ambiente você se sente mais conectado ao divino?',
    options: [
      { text: 'Na natureza, entre árvores e montanhas.', masters: ['kuthumi'] },
      { text: 'Em um templo antigo, silencioso e solene.', masters: ['serapis-bey', 'el-morya'] },
      { text: 'Em um círculo de oração com outras pessoas.', masters: ['afra', 'jesus-sananda'] },
      { text: 'Diante de uma chama acesa, em meditação.', masters: ['saint-germain'] },
    ],
  },
  {
    question: 'Qual cor mais atrai você neste momento?',
    options: [
      { text: 'Azul safira.', masters: ['el-morya'] },
      { text: 'Violeta.', masters: ['saint-germain', 'afra'] },
      { text: 'Rosa ou dourado.', masters: ['lady-nada', 'jesus-sananda', 'kuthumi'] },
      { text: 'Verde-esmeralda ou branco.', masters: ['hilarion', 'serapis-bey'] },
    ],
  },
  {
    question: 'Como você gostaria de servir ao mundo?',
    options: [
      { text: 'Curando pessoas no corpo e na alma.', masters: ['hilarion'] },
      { text: 'Ensinando e compartilhando sabedoria.', masters: ['kuthumi'] },
      { text: 'Liderando com integridade e protegendo os que precisam.', masters: ['el-morya'] },
      { text: 'Acolhendo e cuidando com amor.', masters: ['lady-nada'] },
    ],
  },
  {
    question: 'O que mais toca você nos ensinamentos espirituais?',
    options: [
      { text: 'A possibilidade de transmutar o passado e recomeçar.', masters: ['saint-germain'] },
      { text: 'O exemplo de amor e sacrifício do Cristo.', masters: ['jesus-sananda'] },
      { text: 'A promessa da ascensão e da união com Deus.', masters: ['serapis-bey'] },
      { text: 'A ideia de que todos somos uma única família.', masters: ['afra'] },
    ],
  },
  {
    question: 'Qual destas frases ressoa mais com você?',
    options: [
      { text: '“A Verdade vos libertará.”', masters: ['hilarion'] },
      { text: '“Seja feita a Tua vontade.”', masters: ['el-morya'] },
      { text: '“Amai-vos uns aos outros.”', masters: ['jesus-sananda', 'lady-nada'] },
      { text: '“Conhece-te a ti mesmo.”', masters: ['kuthumi', 'serapis-bey'] },
    ],
  },
  {
    question: 'Qual é seu maior desafio atualmente?',
    options: [
      { text: 'Magóas e dificuldade de perdoar.', masters: ['saint-germain', 'jesus-sananda'] },
      { text: 'Falta de foco e constância.', masters: ['serapis-bey', 'el-morya'] },
      { text: 'Questões de saúde ou dúvidas sobre o caminho.', masters: ['hilarion'] },
      { text: 'Sentimento de isolamento ou desarmonia nos relacionamentos.', masters: ['afra', 'lady-nada'] },
    ],
  },
  {
    question: 'Qual prática espiritual você mais gostaria de aprofundar?',
    options: [
      { text: 'Decretos dinâmicos e invocações da Chama Violeta.', masters: ['saint-germain'] },
      { text: 'Meditação silenciosa e contemplação.', masters: ['kuthumi'] },
      { text: 'Oração de cura e visualização de luz.', masters: ['hilarion', 'jesus-sananda'] },
      { text: 'Serviço voluntário e trabalhos em grupo.', masters: ['lady-nada', 'afra'] },
    ],
  },
  {
    question: 'Ao final da vida, como você gostaria de ser lembrado?',
    options: [
      { text: 'Como alguém que foi fiel aos seus princípios.', masters: ['el-morya', 'serapis-bey'] },
      { text: 'Como alguém que amou profundamente.', masters: ['jesus-sananda', 'lady-nada'] },
      { text: 'Como alguém que ajudou outros a se libertarem.', masters: ['saint-germain', 'afra'] },
      { text: 'Como alguém sábio e compassivo.', masters: ['kuthumi', 'hilarion'] },
    ],
  },
]

export const QUIZ_RESULTS: Record<string, string> = {
  'saint-germain':
    'Sua alma vibra na frequência da liberdade e da transformação. Saint Germain caminha com você como mestre alquimista, ensinando a usar a Chama Violeta para dissolver o peso do passado e abrir espaço para o novo. Você tem o dom de transformar ambientes e pessoas pela sua presença leve e perdoadora. Pratique diariamente decretos de Chama Violeta e observe como sua vida se torna mais fluida e alegre.',
  'el-morya':
    'Você possui uma alma de guerreiro espiritual, com senso de dever, integridade e coragem. El Morya, mestre da Vontade de Deus, o inspira a assumir sua liderança com humildade e fé. Seu desafio é entregar o controle ao Plano Divino, confiando que a Vontade de Deus é sempre boa. Invoque a Chama Azul e a proteção do Arcanjo Miguel todos os dias.',
  'jesus-sananda':
    'Seu coração é um altar de amor. Jesus/Sananda ressoa com você como o exemplo máximo do Cristo interior manifestado. Você tem uma capacidade natural de acolher, perdoar e trazer paz. Seu caminho é reconhecer o Cristo em si mesmo e em cada pessoa. Medite na Chama da Ressurreição e no decreto “Eu Sou a Ressurreição e a Vida”.',
  kuthumi:
    'Você é um buscador da sabedoria, com mente contemplativa e coração gentil. Kuthumi, o mestre do amor sábio, o guia no caminho da meditação e do autoconhecimento. Você tem vocacão para ensinar e para harmonizar mente e emoções. Passe tempo na natureza e dedique alguns minutos diários ao silêncio interior.',
  'lady-nada':
    'Sua essência é o amor em ação. Lady Nada, mestra do serviço e da harmonia, reconhece em você uma alma dedicada a cuidar e a unir. Seu dom é curar relacionamentos com palavras doces e gestos sinceros. Lembre-se de incluir a si mesmo no círculo do seu amor. Visualize a Chama Rosa envolvendo seu coração e todos que você ama.',
  'serapis-bey':
    'Você carrega a chama da pureza e da determinação. Serapis Bey, hierarca do Templo da Ascensão em Luxor, o acompanha na jornada de disciplina amorosa rumo à união com sua Presença Eu Sou. Você tem força interior para manter práticas espirituais constantes. Invoque a Chama Branca da Ascensão e celebre cada pequena vitória.',
  hilarion:
    'Sua alma busca a Verdade e tem o dom da cura. Hilarion, mestre da Chama Verde, caminha com você unindo ciência, intuição e espiritualidade. Você tem o potencial de ser um canal de cura para muitos. Seu caminho é acolher a verdade com honestidade e usar sua visão clara a serviço dos outros. Visualize a luz esmeralda envolvendo seu corpo.',
  afra:
    'Você é uma ponte entre pessoas e povos. Afra, mestre da unidade e da fraternidade, ressoa com seu desejo profundo de pertencimento e de ver toda a humanidade como uma só família. Seu dom é unir, acolher a diversidade e fortalecer comunidades. Participe de trabalhos espirituais em grupo e envie Chama Violeta à cura coletiva da humanidade.',
}
