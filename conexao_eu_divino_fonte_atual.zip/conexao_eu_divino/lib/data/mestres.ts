export interface Master {
  slug: string
  name: string
  title: string
  flame: string
  ray: string
  color: string
  image: string
  virtues: string[]
  retreat: string
  summary: string
  message: string
  teachings: string[]
  bio: string[]
  decree: string
}

export const MASTERS: Master[] = [
  {
    slug: 'saint-germain',
    name: 'Saint Germain',
    title: 'Hierarca da Era de Aquário',
    flame: 'Chama Violeta',
    ray: '7º Raio — Liberdade e Transmutação',
    color: '#A855F7',
    image: 'https://cdn.abacus.ai/images/fd0e8833-6550-4018-9b85-1b0daa882fce.png',
    virtues: ['Liberdade', 'Transmutação', 'Misericórdia', 'Alquimia', 'Perdão'],
    retreat: 'Caverna dos Símbolos (EUA) e Castelo de Luz na Transilvânia',
    summary: 'Guardião da Chama Violeta e mestre da alquimia espiritual, conduz a humanidade para a Idade de Ouro.',
    message: 'A Chama Violeta é a chave da tua liberdade. Usa-a com amor e persistência, e nenhuma corrente poderá te prender.',
    teachings: [
      'O uso diário da Chama Violeta para transmutar carma e padrões negativos.',
      'A Lei do Perdão como porta de entrada para toda cura.',
      'O poder do “Eu Sou” como palavra criadora.',
      'A alquimia interior: transformar chumbo humano em ouro divino.',
    ],
    bio: [
      'Saint Germain é o Mestre Ascencionado que dirige o Sétimo Raio, o raio violeta da liberdade, da misericórdia, da transmutação e do ritual. Segundo os ensinamentos da Grande Fraternidade Branca, ele é o hierarca da Era de Aquário, responsável por guiar a humanidade nos próximos dois mil anos.',
      'A tradição o associa a diversas encarnações de serviço: o profeta Samuel, São José (pai terreno de Jesus), Merlin na corte do Rei Artur, Roger Bacon, Cristóvão Colombo e Francis Bacon. Como o misterioso Conde de Saint Germain, circulou pelas cortes europeias do século XVIII tentando evitar derramamento de sangue.',
      'Após sua ascensão, recebeu a dispensação de liberar à humanidade o conhecimento da Chama Violeta — uma energia espiritual que dissolve registros negativos do passado. Foi através dele que o ensinamento da Presença Eu Sou chegou de forma clara ao mundo ocidental no século XX.',
    ],
    decree: 'Eu Sou a Chama Violeta em ação em mim agora! Eu Sou a Chama Violeta, somente à Luz me rendo! Eu Sou a Chama Violeta, em poderosa força cósmica! Eu Sou a Luz de Deus a todo momento resplandecendo!',
  },
  {
    slug: 'el-morya',
    name: 'El Morya',
    title: 'Chohan do Primeiro Raio',
    flame: 'Chama Azul',
    ray: '1º Raio — Vontade de Deus',
    color: '#3B82F6',
    image: 'https://cdn.abacus.ai/images/1f848398-cb7b-4cb3-99dd-695e046f13e4.png',
    virtues: ['Fé', 'Poder', 'Proteção', 'Obediência à Lei', 'Liderança'],
    retreat: 'Templo da Boa Vontade, em Darjeeling (Índia)',
    summary: 'Mestre da Vontade Divina, ensina a fé inabalável, a liderança servidora e a entrega ao Plano de Deus.',
    message: 'A Vontade de Deus é boa. Quando te entregas a ela, descobres que ela sempre foi o teu mais profundo desejo.',
    teachings: [
      'A entrega consciente à Vontade Divina.',
      'A fé como força ativa, não como espera passiva.',
      'A liderança baseada no serviço e na integridade.',
      'A proteção pela Chama Azul e pelo Arcanjo Miguel.',
    ],
    bio: [
      'El Morya é o Chohan (senhor) do Primeiro Raio, o raio azul da vontade de Deus, da fé, do poder e da proteção. É conhecido por seu amor intenso e exigente, que desafia os discípulos a darem o melhor de si.',
      'A tradição esotérica o associa a encarnações como Abraão, Melchior (um dos Reis Magos), o Rei Artur, Thomas Becket, Thomas More e o imperador mogol Akbar, o Grande. Foi um dos mestres que inspiraram a fundação da Sociedade Teosófica no século XIX.',
      'Dirige o Templo da Boa Vontade, um retiro etérico sobre Darjeeling, onde discípulos são treinados durante o sono no uso correto do poder, da diplomacia e do governo divino.',
    ],
    decree: 'Eu Sou a Vontade de Deus em ação! Amado El Morya, carrega-me em teu Coração de Diamante e sela-me na Chama Azul da fé, da proteção e do poder divino!',
  },
  {
    slug: 'jesus-sananda',
    name: 'Jesus / Sananda',
    title: 'Instrutor Mundial',
    flame: 'Chama Rosa-Dourada',
    ray: '6º Raio — Amor Crístico e Serviço',
    color: '#F59E9E',
    image: 'https://cdn.abacus.ai/images/5e6a3ae6-a504-488b-90c2-0fee277475c1.png',
    virtues: ['Amor Crístico', 'Paz', 'Serviço', 'Ressurreição', 'Compaixão'],
    retreat: 'Templo da Ressurreição, sobre a Terra Santa',
    summary: 'Exemplo supremo da Consciência Crística, mostrou que a ascensão é o destino de toda alma.',
    message: 'Eu Sou a Ressurreição e a Vida. O que eu fiz foi para mostrar o que tu também podes ser.',
    teachings: [
      'O Cristo como Luz presente em cada ser humano.',
      'O amor incondicional e o perdão como leis supremas.',
      'A Chama da Ressurreição para restaurar a vida em todos os níveis.',
      'O caminho da ascensão demonstrado por sua própria vida.',
    ],
    bio: [
      'Nos ensinamentos da Grande Fraternidade Branca, Jesus é reverenciado como o Mestre Ascencionado que demonstrou plenamente a união com o Cristo interior. Sananda é seu nome cósmico, utilizado em muitas correntes espirituais.',
      'Sua vida, crucificação, ressurreição e ascensão são vistas como as etapas iniciáticas que toda alma um dia percorrerá. Ele serve, junto com Kuthumi, no cargo de Instrutor Mundial.',
      'Sua chama é rosa-dourada: o ouro da paz e da sabedoria unido ao rosa do amor. Ele nos convida a enxergar o Cristo em cada irmão.',
    ],
    decree: 'Eu Sou a Ressurreição e a Vida! Amado Jesus, que a tua Chama da Paz e do Amor Crístico se expanda em meu coração e em toda a Terra!',
  },
  {
    slug: 'kuthumi',
    name: 'Kuthumi',
    title: 'Instrutor Mundial',
    flame: 'Chama Amarela',
    ray: '2º Raio — Sabedoria e Iluminação',
    color: '#FACC15',
    image: 'https://cdn.abacus.ai/images/29bcf372-5b1b-47f3-9c2f-37c163c3ddc0.png',
    virtues: ['Sabedoria', 'Iluminação', 'Compreensão', 'Humildade', 'Paz interior'],
    retreat: 'Retiro em Shigatse (Tibete) e na Caxemira',
    summary: 'Mestre do amor sábio, ensina a meditação, o equilíbrio emocional e a iluminação da mente.',
    message: 'A verdadeira sabedoria é simples. Ela se revela a quem sabe silenciar e amar.',
    teachings: [
      'A meditação como caminho para a Mente de Cristo.',
      'O equilíbrio entre intelecto e coração.',
      'A harmonia com a natureza e os reinos elementais.',
      'A cura das emoções pela compreensão amorosa.',
    ],
    bio: [
      'Kuthumi serve com Jesus no cargo de Instrutor Mundial e já foi Chohan do Segundo Raio, o raio dourado da sabedoria e iluminação. É conhecido por sua ternura, paciência e profundo amor pela natureza.',
      'A tradição o associa a Pitágoras, a Baltasar (um dos Reis Magos), a São Francisco de Assis e ao Mahatma Koot Hoomi, que junto com El Morya inspirou os ensinamentos teosóficos.',
      'Seus ensinamentos enfatizam o equilíbrio psicológico do discípulo, a cura das feridas emocionais e a aplicação prática da sabedoria no dia a dia.',
    ],
    decree: 'Eu Sou a Sabedoria de Deus em ação! Amado Kuthumi, ilumina minha mente com a Chama Dourada e envolve meu coração em tua paz!',
  },
  {
    slug: 'lady-nada',
    name: 'Lady Nada',
    title: 'Chohan do Sexto Raio',
    flame: 'Chama Rosa',
    ray: 'Raio Rubi-Dourado — Amor e Serviço',
    color: '#F472B6',
    image: 'https://cdn.abacus.ai/images/754028d0-fdd4-4354-a330-318135003591.png',
    virtues: ['Amor', 'Serviço', 'Paz', 'Doçura', 'Advocacia divina'],
    retreat: 'Retiro na Arábia Saudita',
    summary: 'Mestra do amor em serviço, ensina a doçura, a harmonia e a cura dos relacionamentos.',
    message: 'O amor que serve sem esperar nada em troca é a força mais poderosa do Universo.',
    teachings: [
      'O serviço desinteressado como caminho de ascensão.',
      'A cura de relacionamentos pela Chama Rosa.',
      'O uso amoroso da palavra falada.',
      'O equilíbrio entre a força e a doçura femininas.',
    ],
    bio: [
      'Lady Nada é a Mestra Ascencionada que serve no Sexto Raio, o raio rubi-dourado da paz, do serviço e da ministração. Seu amor é suave e ao mesmo tempo firme como o de uma advogada divina.',
      'Segundo a tradição, em uma de suas encarnações na Atlântida ela escolheu servir silenciosamente aos seus irmãos, desenvolvendo o amor como atributo principal. Essa entrega a conduziu à ascensão.',
      'Ela ensina que o amor verdadeiro se expressa em ações concretas e que cada gesto de serviço, por menor que seja, ecoa no coração de Deus.',
    ],
    decree: 'Eu Sou o Amor Divino em ação! Amada Lady Nada, expande em mim a Chama Rosa do serviço e harmoniza todos os meus relacionamentos!',
  },
  {
    slug: 'serapis-bey',
    name: 'Serapis Bey',
    title: 'Chohan do Quarto Raio',
    flame: 'Chama Branca',
    ray: '4º Raio — Ascensão e Disciplina',
    color: '#E2E8F0',
    image: 'https://cdn.abacus.ai/images/99532ba9-c3a6-4bb3-97fb-553702dc893c.png',
    virtues: ['Pureza', 'Disciplina', 'Ascensão', 'Esperança', 'Arte sagrada'],
    retreat: 'Templo da Ascensão, em Luxor (Egito)',
    summary: 'Hierarca do Templo de Luxor, guia os candidatos à ascensão pela pureza e disciplina amorosa.',
    message: 'A ascensão não é um prêmio distante, mas a soma das pequenas vitórias que conquistas hoje.',
    teachings: [
      'A disciplina como expressão de amor por si mesmo.',
      'A pureza de motivação em todas as ações.',
      'Os degraus iniciáticos da ascensão.',
      'A geometria sagrada e a arte como pontes para o divino.',
    ],
    bio: [
      'Serapis Bey é o Chohan do Quarto Raio, o raio branco da pureza, da ascensão e da disciplina. Ele dirige o Templo da Ascensão em Luxor, no Egito, onde a Chama da Ascensão é guardada há milênios.',
      'A tradição o associa a um sacerdote do Templo da Ascensão na Atlântida, ao faraó Amenhotep III e ao rei Leônidas de Esparta. É conhecido por sua firmeza e por exigir dos discípulos seriedade e dedicação.',
      'Seu ensinamento central é que a ascensão está ao alcance de todos que se dispuserem a purificar consciência, sentimentos e hábitos com perseverança e alegria.',
    ],
    decree: 'Eu Sou a Chama da Ascensão! Amado Serapis Bey, purifica-me com a Chama Branca e eleva-me, degrau a degrau, à minha Presença Eu Sou!',
  },
  {
    slug: 'hilarion',
    name: 'Hilarion',
    title: 'Chohan do Quinto Raio',
    flame: 'Chama Verde',
    ray: '5º Raio — Cura e Verdade',
    color: '#22C55E',
    image: 'https://cdn.abacus.ai/images/ce287ba4-84da-4bc8-9489-000caef62751.png',
    virtues: ['Verdade', 'Cura', 'Ciência', 'Consagração', 'Visão'],
    retreat: 'Templo da Verdade, em Creta (Grécia)',
    summary: 'Mestre da Verdade e da Cura, une ciência e espiritualidade e liberta os que buscam sinceramente.',
    message: 'A Verdade não é dura — ela é libertadora. Acolhe-a e a cura se manifestará naturalmente.',
    teachings: [
      'A cura como restauração da Verdade Divina no ser.',
      'A união entre ciência e espiritualidade.',
      'O poder da visão concentrada (o Olho Onividente).',
      'O acolhimento dos que duvidam e buscam provas.',
    ],
    bio: [
      'Hilarion é o Chohan do Quinto Raio, o raio verde-esmeralda da verdade, da cura, da ciência e da precipitação. Ele trabalha especialmente com médicos, cientistas, terapeutas e buscadores da verdade.',
      'A tradição o associa ao apóstolo Paulo, que teve seu encontro transformador com o Cristo no caminho de Damasco, e a Santo Hilarião, eremita e curador do século IV.',
      'Por ter passado ele próprio pela dúvida e pela conversão, tem especial compaixão pelos céticos e ajuda-os a encontrar a Verdade que liberta.',
    ],
    decree: 'Eu Sou a Verdade e a Cura de Deus! Amado Hilarion, banha-me na Chama Verde-Esmeralda e restaura em mim a Perfeição Divina!',
  },
  {
    slug: 'afra',
    name: 'Afra',
    title: 'Patrono da África',
    flame: 'Chama Violeta',
    ray: 'Chama da Unidade e Fraternidade',
    color: '#8B5CF6',
    image: 'https://cdn.abacus.ai/images/f18145a3-c58e-49dd-9bc1-0711afd52a7e.png',
    virtues: ['Fraternidade', 'Unidade', 'Liberdade', 'Resiliência', 'Devoção'],
    retreat: 'Focos de luz sobre o continente africano',
    summary: 'Primeiro Mestre Ascencionado da raça negra, dedicado à unidade e à fraternidade de todos os povos.',
    message: 'Somos uma única família sob o mesmo Sol. Quando um irmão é libertado, todos nós somos libertados.',
    teachings: [
      'A fraternidade como expressão prática do amor divino.',
      'A superação das divisões entre povos e raças.',
      'A Chama Violeta aplicada à cura coletiva.',
      'A força espiritual que nasce da unidade.',
    ],
    bio: [
      'Afra é reverenciado como o Mestre Ascencionado patrono da África e o primeiro da raça negra a alcançar a ascensão. Seu nome deu origem à palavra “África”.',
      'Segundo a tradição, ele se ofereceu para servir seu povo ao longo de muitas encarnações, ensinando que a verdadeira força de um povo está em sua união e em sua fidelidade à Luz.',
      'Ele trabalha com a Chama Violeta para libertar a humanidade das feridas coletivas do passado, promovendo a unidade e a fraternidade entre todos os povos da Terra.',
    ],
    decree: 'Eu Sou a Unidade de toda a Vida! Amado Afra, que a Chama Violeta da Fraternidade una todos os corações da Terra em uma só família de Luz!',
  },
]

export function getMaster(slug: string): Master | undefined {
  return MASTERS.find((m: Master) => m?.slug === slug)
}

export interface SacredFlame {
  name: string
  ray: string
  color: string
  master: string
  quality: string
  message: string
  decree: string
}

export const SACRED_FLAMES: SacredFlame[] = [
  { name: 'Chama Azul', ray: '1º Raio', color: '#3B82F6', master: 'El Morya', quality: 'Fé, Vontade de Deus e Proteção', message: 'Hoje é dia de coragem. Firma teus propósitos na Vontade de Deus e caminha protegido.', decree: 'Eu Sou a Vontade de Deus em ação! Eu Sou a Fé que remove montanhas!' },
  { name: 'Chama Dourada', ray: '2º Raio', color: '#EAB308', master: 'Kuthumi', quality: 'Sabedoria e Iluminação', message: 'A clareza que buscas está disponível. Silencia, estuda e deixa a Luz iluminar tua mente.', decree: 'Eu Sou a Mente de Deus pensando através de mim! Eu Sou a Iluminação Divina!' },
  { name: 'Chama Rosa', ray: '3º Raio', color: '#EC4899', master: 'Paulo, o Veneziano', quality: 'Amor Divino e Adoração', message: 'Abre teu coração. O amor que ofereces hoje voltará a ti multiplicado.', decree: 'Eu Sou o Amor Divino que tudo harmoniza! Eu Sou a Chama Rosa em ação!' },
  { name: 'Chama Branca', ray: '4º Raio', color: '#E5E7EB', master: 'Serapis Bey', quality: 'Pureza e Ascensão', message: 'Purifica teus pensamentos e hábitos. Cada escolha pura é um degrau rumo à Luz.', decree: 'Eu Sou a Chama da Ascensão! Eu Sou a Pureza de Deus em tudo que faço!' },
  { name: 'Chama Verde', ray: '5º Raio', color: '#22C55E', master: 'Hilarion', quality: 'Verdade e Cura', message: 'A cura está em curso. Acolhe a Verdade com humildade e teu ser se restaurará.', decree: 'Eu Sou a Verdade e a Cura de Deus! Eu Sou a Perfeição Divina manifesta!' },
  { name: 'Chama Rubi-Dourada', ray: '6º Raio', color: '#DC2626', master: 'Lady Nada', quality: 'Paz, Serviço e Devoção', message: 'Serve com alegria hoje. No serviço amoroso encontrarás tua paz mais profunda.', decree: 'Eu Sou a Paz de Deus em ação! Eu Sou o Serviço amoroso a toda a vida!' },
  { name: 'Chama Violeta', ray: '7º Raio', color: '#A855F7', master: 'Saint Germain', quality: 'Liberdade e Transmutação', message: 'Solta o passado. A Chama Violeta está pronta para transmutar tudo o que te pesa.', decree: 'Eu Sou um ser de Fogo Violeta! Eu Sou a pureza que Deus deseja!' },
]
