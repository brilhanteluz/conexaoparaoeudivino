import type { Metadata } from 'next'
import { Users, Globe, Star, Heart } from 'lucide-react'
import { PageHero, SectionTitle } from '@/components/page-hero'
import { Reveal } from '@/components/reveal'
import { MASTERS } from '@/lib/data/mestres'
import { MastersGrid } from './_components/masters-grid'

export const metadata: Metadata = {
  title: 'Mestres Ascencionados',
  description: 'Conheça os Mestres Ascencionados da Grande Fraternidade Branca: Saint Germain, El Morya, Jesus, Kuthumi, Lady Nada, Serapis Bey, Hilarion e Afra.',
}

export default function MestresPage() {
  return (
    <>
      <PageHero
        icon={Users}
        eyebrow="Grande Fraternidade Branca"
        title="Mestres Ascencionados"
        description="Seres que um dia caminharam pela Terra como nós, venceram as provas da vida e se uniram à sua Presença Eu Sou. Hoje, servem com amor à evolução da humanidade."
      />

      <section className="mx-auto max-w-[1200px] px-6 pb-16">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            { icon: Globe, t: 'O que é a Fraternidade', d: 'A Grande Fraternidade Branca é uma hierarquia espiritual de Mestres Ascencionados, Arcanjos e seres cósmicos. “Branca” refere-se à aura de luz branca que os envolve — não a raça ou cor.' },
            { icon: Star, t: 'O que é a Ascensão', d: 'Ascender é unir-se plenamente à Presença Eu Sou, libertando-se da roda de renascimentos. Os Mestres alcançaram essa vitória e mostram que ela está ao alcance de todos.' },
            { icon: Heart, t: 'Como eles servem', d: 'Cada Mestre dirige um dos raios divinos, mantém retiros etéricos onde as almas são instruídas durante o sono e responde a todos que o invocam com sinceridade.' },
          ].map((c, i: number) => {
            const Icon = c.icon
            return (
              <Reveal key={c.t} delay={i * 0.1}>
                <div className="glass h-full rounded-xl p-6">
                  <Icon className="mb-3 h-6 w-6 text-primary" />
                  <h2 className="font-display text-lg font-semibold">{c.t}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{c.d}</p>
                </div>
              </Reveal>
            )
          })}
        </div>
      </section>

      <section className="bg-accent/10 py-20">
        <div className="mx-auto max-w-[1200px] px-6">
          <SectionTitle eyebrow="Os Guias" title="Conheça os Mestres e suas Chamas" description="Clique em um Mestre para ler seus ensinamentos, virtudes e decreto." />
          <MastersGrid masters={MASTERS} />
        </div>
      </section>
    </>
  )
}
