import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import { ArrowLeft, Flame, MapPin, Sparkles, Quote } from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { CopyButton } from '@/components/copy-button'
import { MASTERS, getMaster } from '@/lib/data/mestres'

export function generateStaticParams() {
  return MASTERS.map((m) => ({ slug: m.slug }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const m = getMaster(slug)
  return { title: m?.name ?? 'Mestre', description: m?.summary ?? '' }
}

export default async function MasterPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const m = getMaster(slug)
  if (!m) notFound()
  const others = MASTERS.filter((x) => x.slug !== m.slug).slice(0, 4)

  return (
    <article className="mx-auto max-w-[1200px] px-6 py-12">
      <Link href="/mestres" className="mb-8 inline-flex items-center gap-2 rounded-md bg-secondary/25 px-4 py-2 text-sm hover:bg-secondary/45 hover:text-primary">
        <ArrowLeft className="h-4 w-4" /> Todos os Mestres
      </Link>

      <div className="grid gap-10 lg:grid-cols-5">
        <Reveal className="lg:col-span-2">
          <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-muted" style={{ boxShadow: `0 0 60px ${m.color}55` }}>
            <Image src={m.image} alt={`Mestre Ascencionado ${m.name}`} fill className="object-cover" sizes="(max-width: 1024px) 100vw, 40vw" priority />
          </div>
        </Reveal>
        <Reveal delay={0.1} className="lg:col-span-3">
          <span className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold" style={{ background: `${m.color}33`, color: m.color }}>
            <Flame className="h-3 w-3" /> {m.flame}
          </span>
          <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight text-gold md:text-5xl">{m.name}</h1>
          <p className="mt-2 text-muted-foreground">{m.title} · {m.ray}</p>
          <div className="mt-6 space-y-4 leading-relaxed text-foreground/85">
            {m.bio.map((p: string) => <p key={p.slice(0, 20)}>{p}</p>)}
          </div>
          <p className="mt-6 flex items-center gap-2 text-sm text-muted-foreground"><MapPin className="h-4 w-4 text-primary" /> Retiro etérico: {m.retreat}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            {m.virtues.map((v: string) => <span key={v} className="rounded-full bg-muted px-3 py-1 text-xs">{v}</span>)}
          </div>
        </Reveal>
      </div>

      <div className="mt-14 grid gap-6 md:grid-cols-2">
        <Reveal>
          <div className="glass h-full rounded-xl p-7">
            <h2 className="mb-4 font-display text-2xl font-semibold">Ensinamentos principais</h2>
            <ul className="space-y-3">
              {m.teachings.map((t: string) => (
                <li key={t} className="flex gap-3 text-foreground/85"><Sparkles className="mt-1 h-4 w-4 shrink-0" style={{ color: m.color }} /> {t}</li>
              ))}
            </ul>
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="glass flex h-full flex-col rounded-xl p-7">
            <Quote className="mb-3 h-7 w-7 text-primary" />
            <p className="font-display text-xl leading-relaxed">“{m.message}”</p>
            <div className="gold-divider my-6" />
            <p className="text-xs font-semibold uppercase tracking-widest text-primary">Decreto</p>
            <p className="mt-2 flex-1 font-display text-gold">{m.decree}</p>
            <div className="mt-4"><CopyButton text={m.decree} /></div>
          </div>
        </Reveal>
      </div>

      <section className="mt-16">
        <h2 className="mb-6 font-display text-2xl font-semibold">Outros Mestres</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {others.map((o) => (
            <Link key={o.slug} href={`/mestres/${o.slug}`} className="glass glass-hover group overflow-hidden rounded-xl">
              <div className="relative aspect-square bg-muted">
                <Image src={o.image} alt={o.name} fill className="object-cover object-top" sizes="25vw" />
              </div>
              <div className="p-3">
                <p className="font-display font-semibold group-hover:text-primary">{o.name}</p>
                <p className="text-xs" style={{ color: o.color }}>{o.flame}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </article>
  )
}
