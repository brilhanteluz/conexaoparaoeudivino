'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useState } from 'react'
import { Flame, MapPin, Sparkles, ArrowRight } from 'lucide-react'
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Reveal } from '@/components/reveal'
import type { Master } from '@/lib/data/mestres'

export function MastersGrid({ masters }: { masters: Master[] }) {
  const [selected, setSelected] = useState<Master | null>(null)
  const list = masters ?? []

  return (
    <>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {list.map((m: Master, i: number) => (
          <Reveal key={m.slug} delay={(i % 4) * 0.08}>
            <button
              type="button"
              onClick={() => setSelected(m)}
              className="glass group flex h-full w-full flex-col overflow-hidden rounded-xl text-left transition-all duration-300 hover:-translate-y-1"
              style={{ boxShadow: `0 10px 30px -10px rgba(0,0,0,.6)` }}
              onMouseEnter={(e: React.MouseEvent<HTMLButtonElement>) => { e.currentTarget.style.boxShadow = `0 14px 40px -8px ${m.color}66` }}
              onMouseLeave={(e: React.MouseEvent<HTMLButtonElement>) => { e.currentTarget.style.boxShadow = '0 10px 30px -10px rgba(0,0,0,.6)' }}
              aria-label={`Ver detalhes de ${m.name}`}
            >
              <div className="relative aspect-[3/4] bg-muted">
                <Image src={m.image} alt={`Mestre Ascencionado ${m.name}`} fill className="object-cover transition-transform duration-700 group-hover:scale-105" sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw" />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/10 to-transparent" />
                <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold backdrop-blur" style={{ background: `${m.color}33`, color: m.color }}>
                  <Flame className="h-3 w-3" /> {m.flame}
                </span>
              </div>
              <div className="relative -mt-12 flex flex-1 flex-col p-5">
                <div className="mb-2 h-1 w-12 rounded-full" style={{ background: m.color }} />
                <h3 className="font-display text-xl font-semibold text-foreground">{m.name}</h3>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">{m.ray}</p>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-foreground/80">{m.summary}</p>
                <p className="mt-3 border-l-2 pl-3 text-sm italic text-foreground/70" style={{ borderColor: m.color }}>“{m.message}”</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary">Conhecer mais <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" /></span>
              </div>
            </button>
          </Reveal>
        ))}
      </div>

      <Dialog open={!!selected} onOpenChange={(o: boolean) => { if (!o) setSelected(null) }}>
        <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto border-0 bg-popover p-0 text-popover-foreground">
          {selected ? (
            <div>
              <div className="relative h-56 w-full bg-muted sm:h-72">
                <Image src={selected.image} alt={`Mestre ${selected.name}`} fill className="object-cover object-top" sizes="768px" />
                <div className="absolute inset-0 bg-gradient-to-t from-popover via-popover/30 to-transparent" />
              </div>
              <div className="-mt-16 relative space-y-5 p-6 sm:p-8">
                <div>
                  <span className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold" style={{ background: `${selected.color}33`, color: selected.color }}>
                    <Flame className="h-3 w-3" /> {selected.flame} · {selected.ray}
                  </span>
                  <DialogTitle className="mt-3 font-display text-3xl font-semibold text-gold">{selected.name}</DialogTitle>
                  <DialogDescription className="text-sm text-muted-foreground">{selected.title}</DialogDescription>
                </div>
                <p className="leading-relaxed text-foreground/85">{selected.bio?.[0] ?? ''}</p>
                <div>
                  <h4 className="mb-2 font-display text-lg font-semibold">Ensinamentos principais</h4>
                  <ul className="space-y-2">
                    {(selected.teachings ?? []).map((t: string) => (
                      <li key={t} className="flex gap-2 text-sm text-foreground/85"><Sparkles className="mt-0.5 h-4 w-4 shrink-0" style={{ color: selected.color }} /> {t}</li>
                    ))}
                  </ul>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(selected.virtues ?? []).map((v: string) => (
                    <span key={v} className="rounded-full bg-muted px-3 py-1 text-xs text-foreground/85">{v}</span>
                  ))}
                </div>
                <p className="flex items-center gap-2 text-sm text-muted-foreground"><MapPin className="h-4 w-4 text-primary" /> Retiro: {selected.retreat}</p>
                <div className="rounded-lg bg-accent/40 p-5">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-widest text-primary">Decreto</p>
                  <p className="font-display text-gold">{selected.decree}</p>
                </div>
                <Link href={`/mestres/${selected.slug}`} className="btn-gold inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold">
                  Ver página completa <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
    </>
  )
}
