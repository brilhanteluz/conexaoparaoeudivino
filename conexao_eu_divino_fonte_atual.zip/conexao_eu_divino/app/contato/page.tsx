import type { Metadata } from 'next'
import { Heart, BookOpen, Users, Sparkles, ExternalLink } from 'lucide-react'
import { PageHero } from '@/components/page-hero'
import { Reveal } from '@/components/reveal'

export const metadata: Metadata = {
  title: 'Sobre & Contato',
  description: 'Conheça mais sobre a Conexão para o Eu Divino e acompanhe nosso conteúdo espiritual.',
}

const LINKS = [
  {
    icon: BookOpen,
    title: 'Blog Espiritual',
    text: 'Artigos, reflexões e mensagens dos Mestres para a sua caminhada interior.',
    href: 'https://conexaoparaoeudivino.blogspot.com/',
    cta: 'Visitar o Blog',
  },
  {
    icon: Users,
    title: 'Facebook',
    text: 'Participe da nossa comunidade, compartilhe experiências e receba atualizações diárias.',
    href: 'https://www.facebook.com/Conexaoparaoeudivino',
    cta: 'Seguir no Facebook',
  },
]

export default function ContatoPage() {
  return (
    <>
      <PageHero
        icon={Heart}
        eyebrow="Sobre nós"
        title="Conexão para o Eu Divino"
        description="Um espaço sagrado de conhecimento, prática e expansão espiritual. Aqui você encontra decretos, meditações, ensinamentos dos Mestres Ascencionados e ferramentas para despertar a Divina Presença Eu Sou em você."
      />
      <section className="mx-auto max-w-[1200px] px-6 pb-20">
        {/* Missão */}
        <Reveal>
          <div className="glass mx-auto mb-12 max-w-3xl rounded-2xl p-8 text-center shadow-lg">
            <Sparkles className="mx-auto mb-4 h-8 w-8 text-primary" />
            <h2 className="font-display mb-3 text-2xl font-bold">Nossa Missão</h2>
            <p className="text-muted-foreground leading-relaxed">
              Levar ensinamentos da Grande Fraternidade Branca, dos Mestres Ascencionados e da Chama Violeta
              a todos os buscadores sinceros, de forma gratuita, amorosa e acessível. Acreditamos que o
              caminho para a paz e a plenitude começa dentro de cada um — na reconexão com o Eu Divino.
            </p>
          </div>
        </Reveal>

        {/* Links */}
        <h2 className="font-display mb-8 text-center text-2xl font-bold">Acompanhe Nosso Trabalho</h2>
        <div className="mx-auto grid max-w-2xl gap-6 sm:grid-cols-2">
          {LINKS.map((link, i: number) => (
            <Reveal key={link.title} delay={0.1 * i}>
              <a
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="glass group flex flex-col items-center gap-4 rounded-2xl p-8 text-center shadow-md transition hover:shadow-xl"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent/60 text-primary transition group-hover:scale-110">
                  <link.icon className="h-7 w-7" />
                </div>
                <h3 className="font-display text-lg font-semibold">{link.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{link.text}</p>
                <span className="mt-auto inline-flex items-center gap-1 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary transition group-hover:bg-primary/20">
                  {link.cta}
                  <ExternalLink className="h-3.5 w-3.5" />
                </span>
              </a>
            </Reveal>
          ))}
        </div>

        {/* Mensagem final */}
        <Reveal delay={0.3}>
          <p className="mx-auto mt-16 max-w-xl text-center text-muted-foreground italic leading-relaxed">
            "A Luz que você procura já existe em você. Permita-se brilhar."
          </p>
        </Reveal>
      </section>
    </>
  )
}
