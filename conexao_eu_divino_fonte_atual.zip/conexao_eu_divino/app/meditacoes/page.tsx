import type { Metadata } from 'next'
import { Flower2, Info } from 'lucide-react'
import { PageHero } from '@/components/page-hero'
import { Reveal } from '@/components/reveal'
import { MEDITATIONS } from '@/lib/data/meditacoes'
import { MeditationCard } from './_components/meditation-card'

export const metadata: Metadata = {
  title: 'Meditações Guiadas',
  description: 'Roteiros completos de meditação guiada: Chama Violeta, conexão com a Presença Eu Sou, cura com Hilarion, proteção com El Morya e amor crístico.',
}

export default function MeditacoesPage() {
  return (
    <>
      <PageHero
        icon={Flower2}
        eyebrow="Silêncio que transforma"
        title="Meditações Guiadas"
        description="Roteiros completos para você ler, gravar com sua própria voz ou conduzir em grupo — cada um sob a radiação de um Mestre e de uma Chama sagrada."
      />
      <section className="mx-auto max-w-[1200px] px-6">
        <Reveal>
          <div className="glass mb-10 flex gap-4 rounded-xl p-5">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
            <p className="text-sm leading-relaxed text-foreground/85">
              <strong className="text-foreground">Dica:</strong> leia o roteiro uma vez antes de praticar. Depois, conduza a si mesmo com calma, fazendo pausas entre cada passo. Você também pode gravar o texto com sua voz e ouvi-lo de olhos fechados.
            </p>
          </div>
        </Reveal>
        <div className="space-y-8">
          {MEDITATIONS.map((m, i: number) => (
            <Reveal key={m.slug} delay={0.05 * (i % 3)}>
              <MeditationCard m={m} />
            </Reveal>
          ))}
        </div>
      </section>
    </>
  )
}
