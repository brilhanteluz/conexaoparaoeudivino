'use client'

import Image from 'next/image'
import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Clock, Flame, ChevronDown, CheckCircle2, BookOpenText } from 'lucide-react'
import type { Meditation } from '@/lib/data/meditacoes'

export function MeditationCard({ m }: { m: Meditation }) {
  const [open, setOpen] = useState(false)
  if (!m) return null

  return (
    <article className="glass overflow-hidden rounded-xl transition-shadow duration-300 hover:shadow-[0_0_40px_-8px_rgba(212,175,55,0.35)]">
      <div className="grid md:grid-cols-5">
        <div className="relative aspect-video bg-muted md:col-span-2 md:aspect-auto md:min-h-[260px]">
          <Image src={m.image} alt={`Meditação ${m.title}`} fill className="object-cover" sizes="(max-width: 768px) 100vw, 40vw" />
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-background/40" />
        </div>
        <div className="flex flex-col p-6 md:col-span-3">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 px-3 py-1 font-semibold text-primary"><Clock className="h-3 w-3" /> {m.duration}</span>
            <span className="inline-flex items-center gap-1 rounded-full px-3 py-1 font-semibold" style={{ background: `${m.color}26`, color: m.color }}><Flame className="h-3 w-3" /> {m.flame}</span>
            <span className="rounded-full bg-muted px-3 py-1 text-foreground/80">{m.master}</span>
          </div>
          <h3 className="mt-3 font-display text-2xl font-semibold">{m.title}</h3>
          <p className="mt-2 flex-1 leading-relaxed text-muted-foreground">{m.description}</p>
          <button
            type="button"
            onClick={() => setOpen((v: boolean) => !v)}
            aria-expanded={open}
            className="btn-gold mt-5 inline-flex w-fit items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold"
          >
            <BookOpenText className="h-4 w-4" />
            {open ? 'Recolher roteiro' : 'Ler roteiro completo'}
            <ChevronDown className={`h-4 w-4 transition-transform ${open ? 'rotate-180' : ''}`} />
          </button>
        </div>
      </div>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.45 }}
            className="overflow-hidden"
          >
            <div className="grid gap-8 bg-background/30 p-6 md:grid-cols-3 md:p-8">
              <div className="rounded-lg bg-accent/30 p-5">
                <h4 className="mb-3 font-display text-lg font-semibold text-gold">Preparação</h4>
                <ul className="space-y-3">
                  {(m.preparation ?? []).map((p: string) => (
                    <li key={p} className="flex gap-2 text-sm text-foreground/85"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> {p}</li>
                  ))}
                </ul>
              </div>
              <div className="md:col-span-2">
                <h4 className="mb-4 font-display text-lg font-semibold text-gold">Roteiro</h4>
                <ol className="space-y-4">
                  {(m.script ?? []).map((s: string, i: number) => (
                    <li key={i} className="flex gap-4">
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/15 text-xs font-bold text-primary">{i + 1}</span>
                      <p className="leading-relaxed text-foreground/90">{s}</p>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </article>
  )
}
