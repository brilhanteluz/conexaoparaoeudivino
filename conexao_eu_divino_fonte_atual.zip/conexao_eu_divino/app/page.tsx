import Link from 'next/link'
import Image from 'next/image'
import { Sun, Users, Flame, Flower2, Sparkles, BookOpen, Quote, ArrowRight, ScrollText } from 'lucide-react'
import { HomeHero, CollectiveCounter } from './_components/home-client'
import { Reveal } from '@/components/reveal'
import { SectionTitle } from '@/components/page-hero'
import { CopyButton } from '@/components/copy-button'
import { DAILY_DECREES, MASTER_MESSAGES, dayIndex } from '@/lib/data/diarios'
import { BLOG_POSTS } from '@/lib/data/blog-posts'

export const dynamic = 'force-dynamic'

const QUICK = [
  { href: '/eu-sou', icon: Sun, title: 'Presença Eu Sou', text: 'Compreenda quem você realmente é: Deus individualizado em seu ser.' },
  { href: '/mestres', icon: Users, title: 'Mestres Ascencionados', text: 'Conheça os guias da Grande Fraternidade Branca e suas chamas.' },
  { href: '/decretos', icon: Flame, title: 'Decretos & Afirmações', text: 'Use a palavra falada para qualificar a Luz divina em sua vida.' },
  { href: '/meditacoes', icon: Flower2, title: 'Meditações Guiadas', text: 'Roteiros completos para conexão, cura, proteção e ascensão.' },
  { href: '/comunidade', icon: Sparkles, title: 'Comunidade & Quiz', text: 'Compartilhe pedidos de luz e descubra qual Mestre guia sua jornada.' },
  { href: '/blog', icon: BookOpen, title: 'Mensagens dos Mestres', text: 'Ensinamentos, práticas e reflexões para iluminar o caminho.' },
]

export default function Home() {
  const decree = DAILY_DECREES?.[dayIndex(DAILY_DECREES?.length ?? 0)] ?? DAILY_DECREES?.[0]
  const message = MASTER_MESSAGES?.[dayIndex(MASTER_MESSAGES?.length ?? 0)] ?? MASTER_MESSAGES?.[0]
  const posts = BLOG_POSTS?.slice?.(0, 3) ?? []

  return (
    <>
      <HomeHero />

      {/* Decreto do Dia */}
      <section className="mx-auto max-w-[1200px] px-6 py-20">
        <Reveal>
          <div className="glass pulse-glow relative mx-auto max-w-3xl overflow-hidden rounded-2xl p-8 text-center md:p-12">
            <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-accent/70 text-primary">
              <ScrollText className="h-6 w-6" />
            </div>
            <p className="text-xs font-semibold uppercase tracking-[0.35em] text-primary/90">Decreto do Dia</p>
            <h2 className="mt-3 font-display text-2xl font-semibold tracking-tight text-foreground md:text-3xl">{decree?.title ?? ''}</h2>
            <p className="mt-6 font-display text-xl leading-relaxed text-gold md:text-2xl">“{decree?.text ?? ''}”</p>
            <p className="mt-6 text-sm text-muted-foreground">Pronuncie três vezes em voz alta, com o coração aberto.</p>
            <div className="mt-6 flex justify-center">
              <CopyButton text={`${decree?.title ?? ''}\n\n${decree?.text ?? ''}`} />
            </div>
          </div>
        </Reveal>
      </section>

      {/* Acesso rápido */}
      <section className="bg-accent/10 py-20">
        <div className="mx-auto max-w-[1200px] px-6">
          <SectionTitle eyebrow="Caminhos de Luz" title="Por onde deseja começar?" description="Cada portal abaixo conduz a um aspecto do caminho espiritual da Presença Eu Sou." />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {QUICK.map((q, i: number) => {
              const Icon = q.icon
              return (
                <Reveal key={q.href} delay={i * 0.08}>
                  <Link href={q.href} className="glass glass-hover group flex h-full flex-col rounded-xl p-6">
                    <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-secondary to-accent text-primary shadow-lg">
                      <Icon className="h-6 w-6" />
                    </div>
                    <h3 className="font-display text-lg font-semibold text-foreground group-hover:text-primary">{q.title}</h3>
                    <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{q.text}</p>
                    <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary">
                      Acessar <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </span>
                  </Link>
                </Reveal>
              )
            })}
          </div>
        </div>
      </section>

      {/* Mensagem dos Mestres */}
      <section className="mx-auto max-w-[1200px] px-6 py-20">
        <Reveal>
          <figure className="relative mx-auto max-w-4xl rounded-2xl bg-gradient-to-br from-accent/60 via-card/50 to-secondary/30 p-10 text-center shadow-2xl md:p-16">
            <Quote className="mx-auto mb-6 h-10 w-10 text-primary/70" />
            <p className="text-xs font-semibold uppercase tracking-[0.35em] text-muted-foreground">Mensagem dos Mestres para hoje</p>
            <blockquote className="mt-6 font-display text-2xl leading-relaxed text-foreground md:text-3xl">“{message?.text ?? ''}”</blockquote>
            <figcaption className="mt-6 font-display text-lg text-gold">— {message?.master ?? ''}</figcaption>
          </figure>
        </Reveal>
      </section>

      {/* Contador */}
      <section className="mx-auto max-w-[1200px] px-6 py-10">
        <Reveal>
          <CollectiveCounter />
        </Reveal>
      </section>

      {/* Blog */}
      <section className="mx-auto max-w-[1200px] px-6 py-20">
        <SectionTitle eyebrow="Blog" title="Ensinamentos Recentes" description="Leituras para nutrir a alma e aprofundar sua prática." />
        <div className="grid gap-6 md:grid-cols-3">
          {posts.map((p, i: number) => (
            <Reveal key={p.slug} delay={i * 0.1}>
              <Link href={`/blog/${p.slug}`} className="glass glass-hover group flex h-full flex-col overflow-hidden rounded-xl">
                <div className="relative aspect-video bg-muted">
                  <Image src={p.image} alt={p.title} fill className="object-cover transition-transform duration-700 group-hover:scale-105" sizes="(max-width: 768px) 100vw, 33vw" />
                  <span className="absolute left-3 top-3 rounded-full bg-background/80 px-3 py-1 text-xs font-semibold text-primary backdrop-blur">{p.category}</span>
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <h3 className="font-display text-lg font-semibold leading-snug text-foreground group-hover:text-primary">{p.title}</h3>
                  <p className="mt-2 line-clamp-3 flex-1 text-sm text-muted-foreground">{p.excerpt}</p>
                  <span className="mt-4 text-xs text-muted-foreground">{p.readTime} de leitura</span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
        <div className="mt-10 text-center">
          <Link href="/blog" className="btn-gold inline-flex items-center gap-2 rounded-full px-7 py-3 font-semibold">
            Ver todos os artigos <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </>
  )
}
