import type { Metadata } from 'next'
import { Users } from 'lucide-react'
import { PageHero, SectionTitle } from '@/components/page-hero'
import { Reveal } from '@/components/reveal'
import { LightWall } from './_components/light-wall'
import { FlameWheel } from './_components/oracle-wheel'
import { MasterQuiz } from './_components/master-quiz'

export const metadata: Metadata = {
  title: 'Comunidade',
  description: 'Mural de pedidos de luz, roda das Chamas Sagradas e quiz para descobrir o Mestre que acompanha você.',
}

export default function ComunidadePage() {
  return (
    <>
      <PageHero
        icon={Users}
        eyebrow="Unidos na Luz"
        title="Comunidade"
        description="Um espaço para compartilhar intenções, receber mensagens dos Mestres e descobrir qual Chama e qual Mestre caminham ao seu lado."
      />

      <section id="pedidos" className="mx-auto max-w-[1200px] px-6 pb-20">
        <SectionTitle eyebrow="Mural de pedidos" title="Pedidos de Luz" description="Compartilhe sua intenção e envie luz aos pedidos dos irmãos. Juntos, nossa força é multiplicada." />
        <Reveal>
          <LightWall />
        </Reveal>
      </section>

      <section id="chamas" className="mx-auto max-w-[1200px] px-6 py-20">
        <SectionTitle eyebrow="Sete Raios" title="Roda das Chamas Sagradas" description="Gire a roda e descubra a Chama que vai iluminar o seu dia." />
        <Reveal>
          <FlameWheel />
        </Reveal>
      </section>

      <section id="quiz" className="bg-muted/30 py-20">
        <div className="mx-auto max-w-[1200px] px-6">
          <SectionTitle eyebrow="Autoconhecimento" title="Qual Mestre caminha com você?" description="Responda às perguntas com o coração e descubra o Mestre Ascensionado mais afim à sua jornada." />
          <Reveal>
            <MasterQuiz />
          </Reveal>
        </div>
      </section>
    </>
  )
}
