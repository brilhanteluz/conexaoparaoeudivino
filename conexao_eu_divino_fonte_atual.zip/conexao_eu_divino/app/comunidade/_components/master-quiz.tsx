'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Compass, ArrowLeft, RefreshCw, ArrowRight, Flame } from 'lucide-react'
import { QUIZ_QUESTIONS, QUIZ_RESULTS, type QuizOption } from '@/lib/data/quiz'
import { MASTERS, getMaster } from '@/lib/data/mestres'
import { ShareButtons } from '@/components/share-buttons'

export function MasterQuiz() {
  const [started, setStarted] = useState(false)
  const [step, setStep] = useState(0)
  const [answers, setAnswers] = useState<string[][]>([])
  const total = QUIZ_QUESTIONS?.length ?? 0
  const done = started && step >= total

  const choose = (opt: QuizOption) => {
    setAnswers((prev: string[][]) => {
      const next = [...(prev ?? [])]
      next[step] = opt?.masters ?? []
      return next
    })
    setStep((s: number) => s + 1)
  }

  const reset = () => {
    setAnswers([])
    setStep(0)
    setStarted(true)
  }

  const computeResult = (): string => {
    const score: Record<string, number> = {}
    for (const m of MASTERS) score[m.slug] = 0
    for (const arr of answers ?? []) {
      const w = 1 / Math.max(arr?.length ?? 1, 1)
      for (const s of arr ?? []) score[s] = (score[s] ?? 0) + w
    }
    let best = MASTERS?.[0]?.slug ?? 'saint-germain'
    for (const k of Object.keys(score ?? {})) if ((score[k] ?? 0) > (score[best] ?? 0)) best = k
    return best
  }

  const resultMaster = done ? getMaster(computeResult()) : undefined
  const q = QUIZ_QUESTIONS?.[step]

  return (
    <div className="glass overflow-hidden rounded-2xl">
      <AnimatePresence mode="wait">
        {!started ? (
          <motion.div key="intro" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center p-10 text-center">
            <div className="pulse-glow mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-accent text-primary"><Compass className="h-8 w-8" /></div>
            <h3 className="font-display text-2xl font-semibold text-gold md:text-3xl">Qual Mestre Ascencionado Guia Você?</h3>
            <p className="mt-3 max-w-xl text-muted-foreground">Responda {total} perguntas com o coração — não com a mente. Ao final, descubra qual Mestre ressoa mais profundamente com sua alma neste momento.</p>
            <button type="button" onClick={() => setStarted(true)} className="btn-gold mt-8 inline-flex items-center gap-2 rounded-full px-8 py-3 font-semibold">
              Começar o Quiz <ArrowRight className="h-4 w-4" />
            </button>
          </motion.div>
        ) : !done && q ? (
          <motion.div key={`q-${step}`} initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.35 }} className="p-6 md:p-10">
            <div className="mb-6 flex items-center justify-between text-sm text-muted-foreground">
              <span>Pergunta {step + 1} de {total}</span>
              {step > 0 ? (
                <button type="button" onClick={() => setStep((s: number) => Math.max(s - 1, 0))} className="inline-flex items-center gap-1 rounded-md bg-secondary/25 px-3 py-1 hover:bg-secondary/45">
                  <ArrowLeft className="h-3 w-3" /> Voltar
                </button>
              ) : null}
            </div>
            <div className="mb-8 h-1.5 w-full overflow-hidden rounded-full bg-muted">
              <motion.div className="h-full bg-gradient-to-r from-secondary to-primary" initial={false} animate={{ width: `${(step / Math.max(total, 1)) * 100}%` }} />
            </div>
            <h3 className="font-display text-xl font-semibold md:text-2xl">{q.question}</h3>
            <div className="mt-6 grid gap-3 md:grid-cols-2">
              {(q.options ?? []).map((o: QuizOption) => (
                <button
                  key={o.text}
                  type="button"
                  onClick={() => choose(o)}
                  className="rounded-xl bg-background/40 p-5 text-left text-foreground/90 shadow-md transition-all hover:-translate-y-0.5 hover:bg-secondary/40 hover:text-foreground hover:shadow-[0_0_24px_-6px_rgba(212,175,55,0.5)]"
                >
                  {o.text}
                </button>
              ))}
            </div>
          </motion.div>
        ) : resultMaster ? (
          <motion.div key="result" initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6 }} className="grid md:grid-cols-5">
            <div className="relative aspect-[3/4] bg-muted md:col-span-2 md:aspect-auto md:min-h-[480px]">
              <Image src={resultMaster.image} alt={`Mestre ${resultMaster.name}`} fill className="object-cover" sizes="(max-width: 768px) 100vw, 40vw" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent md:bg-gradient-to-r" />
            </div>
            <div className="p-6 md:col-span-3 md:p-10">
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">O Mestre que guia você é</p>
              <h3 className="mt-2 font-display text-4xl font-semibold text-gold">{resultMaster.name}</h3>
              <span className="mt-2 inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold" style={{ background: `${resultMaster.color}33`, color: resultMaster.color }}>
                <Flame className="h-3 w-3" /> {resultMaster.flame} · {resultMaster.ray}
              </span>
              <p className="mt-5 leading-relaxed text-foreground/90">{QUIZ_RESULTS?.[resultMaster.slug] ?? resultMaster.summary}</p>
              <div className="mt-5 rounded-lg bg-accent/40 p-5">
                <p className="text-xs font-semibold uppercase tracking-widest text-primary">Seu decreto</p>
                <p className="mt-2 font-display text-gold">{resultMaster.decree}</p>
              </div>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link href={`/mestres/${resultMaster.slug}`} className="btn-gold inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold">
                  Conhecer {resultMaster.name} <ArrowRight className="h-4 w-4" />
                </Link>
                <button type="button" onClick={reset} className="inline-flex items-center gap-2 rounded-full bg-secondary/30 px-6 py-3 text-sm font-semibold hover:bg-secondary/50">
                  <RefreshCw className="h-4 w-4" /> Refazer
                </button>
              </div>
              <div className="mt-6">
                <ShareButtons title={`Descobri que ${resultMaster.name} é o Mestre que me guia! Faça o quiz também:`} path="/comunidade" />
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  )
}
