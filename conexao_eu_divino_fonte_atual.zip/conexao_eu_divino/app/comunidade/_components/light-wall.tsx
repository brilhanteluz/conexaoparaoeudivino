'use client'

import { useEffect, useState, type FormEvent } from 'react'
import { motion } from 'framer-motion'
import { Heart, Send, User, Loader2, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react'
import { SafeDate } from '@/components/safe-format'

interface LightRequest {
  id: string
  name: string
  intention: string
  createdAt: string
}

export function LightWall() {
  const [items, setItems] = useState<LightRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [name, setName] = useState('')
  const [intention, setIntention] = useState('')
  const [sending, setSending] = useState(false)
  const [status, setStatus] = useState<{ type: 'ok' | 'error'; text: string } | null>(null)

  const load = async () => {
    try {
      const res = await fetch('/api/light-requests', { cache: 'no-store' })
      const data = (await res.json()) as { requests?: LightRequest[] }
      setItems(data?.requests ?? [])
    } catch (err) {
      console.error('Erro ao carregar pedidos:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    if (sending) return
    setStatus(null)
    if (name.trim().length < 2 || intention.trim().length < 5) {
      setStatus({ type: 'error', text: 'Informe seu nome e uma intenção com pelo menos 5 caracteres.' })
      return
    }
    setSending(true)
    try {
      const res = await fetch('/api/light-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, intention }),
      })
      const data = (await res.json()) as { error?: string }
      if (!res.ok) throw new Error(data?.error ?? 'Erro ao enviar.')
      setName('')
      setIntention('')
      setStatus({ type: 'ok', text: 'Seu pedido foi acolhido na Luz. Que seja manifestado segundo a Vontade Divina!' })
      await load()
    } catch (err) {
      console.error('Erro ao enviar pedido:', err)
      setStatus({ type: 'error', text: err instanceof Error ? err.message : 'Não foi possível enviar agora.' })
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-5">
      <form onSubmit={submit} className="glass rounded-xl p-6 shadow-lg lg:col-span-2">
        <div className="mb-5 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/60 text-primary">
            <Heart className="h-5 w-5" />
          </div>
          <h3 className="font-display text-xl font-semibold">Deixe seu pedido de Luz</h3>
        </div>
        <label htmlFor="lw-name" className="mb-1.5 block text-sm font-medium">Seu nome</label>
        <div className="relative mb-4">
          <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            id="lw-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={60}
            placeholder="Como deseja ser lembrado(a)"
            className="w-full rounded-md bg-background/70 py-2.5 pl-10 pr-3 text-sm shadow-inner outline-none ring-1 ring-border focus:ring-2 focus:ring-primary"
          />
        </div>
        <label htmlFor="lw-int" className="mb-1.5 block text-sm font-medium">Sua intenção</label>
        <textarea
          id="lw-int"
          value={intention}
          onChange={(e) => setIntention(e.target.value)}
          maxLength={500}
          rows={5}
          placeholder="Ex.: Peço luz e cura para minha família..."
          className="w-full resize-none rounded-md bg-background/70 p-3 text-sm shadow-inner outline-none ring-1 ring-border focus:ring-2 focus:ring-primary"
        />
        <p className="mt-1 text-right text-xs text-muted-foreground">{intention.length}/500</p>
        {status ? (
          <div className={`mt-3 flex gap-2 rounded-md p-3 text-sm ${status.type === 'ok' ? 'bg-primary/10 text-foreground' : 'bg-destructive/10 text-destructive'}`}>
            {status.type === 'ok' ? <CheckCircle2 className="h-4 w-4 shrink-0 text-primary" /> : <AlertCircle className="h-4 w-4 shrink-0" />}
            <span>{status.text}</span>
          </div>
        ) : null}
        <button
          type="submit"
          disabled={sending}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-md transition hover:bg-primary/90 hover:shadow-lg disabled:opacity-60"
        >
          {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          Enviar à Luz
        </button>
        <p className="mt-3 text-xs text-muted-foreground">Seu nome e intenção ficarão visíveis no mural para que outros irmãos enviem luz a você.</p>
      </form>

      <div className="lg:col-span-3">
        {loading ? (
          <div className="flex h-full min-h-[200px] items-center justify-center text-muted-foreground">
            <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Carregando pedidos...
          </div>
        ) : (items?.length ?? 0) === 0 ? (
          <div className="glass flex h-full min-h-[200px] flex-col items-center justify-center rounded-xl p-6 text-center">
            <Sparkles className="mb-3 h-8 w-8 text-primary" />
            <p className="text-muted-foreground">Ainda não há pedidos. Seja o primeiro a acender uma chama no mural.</p>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {items.map((r: LightRequest, i: number) => (
              <motion.div
                key={r?.id ?? i}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.04 * i }}
                className="rounded-lg bg-card p-5 shadow-md transition hover:shadow-xl"
              >
                <div className="mb-2 flex items-center justify-between gap-2">
                  <span className="flex items-center gap-2 font-semibold text-card-foreground">
                    <Heart className="h-4 w-4 text-primary" /> {r?.name ?? 'Irmão(ã)'}
                  </span>
                  <SafeDate date={r?.createdAt} options={{ day: '2-digit', month: 'short' }} className="text-xs text-muted-foreground" />
                </div>
                <p className="text-sm leading-relaxed text-card-foreground/80">{r?.intention ?? ''}</p>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
