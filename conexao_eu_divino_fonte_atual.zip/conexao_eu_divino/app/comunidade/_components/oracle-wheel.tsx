'use client'

import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { RotateCw, Flame } from 'lucide-react'
import { CopyButton } from '@/components/copy-button'
import { SACRED_FLAMES, type SacredFlame } from '@/lib/data/mestres'

const SIZE = 300
const C = SIZE / 2
const R = 140

function polar(deg: number, r: number): [number, number] {
  const rad = ((deg - 90) * Math.PI) / 180
  const round = (v: number) => Math.round(v * 100) / 100
  return [round(C + r * Math.cos(rad)), round(C + r * Math.sin(rad))]
}

export function FlameWheel() {
  const flames = SACRED_FLAMES ?? []
  const n = flames.length || 1
  const seg = 360 / n
  const [rotation, setRotation] = useState(0)
  const [spinning, setSpinning] = useState(false)
  const [result, setResult] = useState<SacredFlame | null>(null)

  const spin = () => {
    if (spinning) return
    const idx = Math.floor(Math.random() * n)
    const center = idx * seg + seg / 2
    const jitter = (Math.random() - 0.5) * seg * 0.6
    const target = rotation - (rotation % 360) + 360 * 6 + (360 - center) + jitter
    setResult(null)
    setSpinning(true)
    setRotation(target)
    setTimeout(() => {
      setResult(flames[idx] ?? null)
      setSpinning(false)
    }, 4200)
  }

  return (
    <div className="glass flex h-full flex-col items-center rounded-2xl p-8 text-center">
      <h3 className="font-display text-2xl font-semibold text-gold">Roda das Chamas</h3>
      <p className="mt-2 max-w-md text-sm text-muted-foreground">Gire a roda e descubra qual das sete chamas sagradas deseja trabalhar com você hoje.</p>

      <div className="relative my-8 w-full max-w-[300px]">
        <div className="absolute left-1/2 top-[-6px] z-10 -translate-x-1/2" aria-hidden="true">
          <div className="h-0 w-0 border-x-[12px] border-t-[22px] border-x-transparent border-t-primary drop-shadow-[0_0_8px_rgba(255,215,0,0.8)]" />
        </div>
        <motion.svg
          viewBox={`0 0 ${SIZE} ${SIZE}`}
          className="w-full drop-shadow-[0_0_30px_rgba(123,47,190,0.5)]"
          animate={{ rotate: rotation }}
          transition={{ duration: 4, ease: [0.17, 0.67, 0.12, 0.99] }}
          role="img"
          aria-label="Roda com as sete chamas sagradas"
        >
          <circle cx={C} cy={C} r={R + 6} fill="hsl(var(--background))" stroke="hsl(var(--primary))" strokeWidth="2" />
          {flames.map((f: SacredFlame, i: number) => {
            const a0 = i * seg
            const a1 = a0 + seg
            const [x0, y0] = polar(a0, R)
            const [x1, y1] = polar(a1, R)
            const mid = a0 + seg / 2
            const [tx, ty] = polar(mid, R * 0.62)
            return (
              <g key={f.name}>
                <path d={`M${C},${C} L${x0},${y0} A${R},${R} 0 0 1 ${x1},${y1} Z`} fill={f.color} fillOpacity={0.85} stroke="hsl(var(--background))" strokeWidth="2" />
                <text x={tx} y={ty} transform={`rotate(${mid} ${tx} ${ty})`} textAnchor="middle" dominantBaseline="middle" fontSize="11" fontWeight="700" fill={i === 3 ? '#1a0533' : '#ffffff'} style={{ fontFamily: 'var(--font-display)' }}>
                  {f.name.replace('Chama ', '')}
                </text>
              </g>
            )
          })}
          <circle cx={C} cy={C} r="26" fill="hsl(var(--accent))" stroke="hsl(var(--primary))" strokeWidth="2" />
        </motion.svg>
        <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <Flame className="flame-flicker h-6 w-6 text-primary" />
        </div>
      </div>

      <div className="min-h-[170px] w-full">
        <AnimatePresence mode="wait">
          {result ? (
            <motion.div key={result.name} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="rounded-xl bg-background/40 p-6 text-left" style={{ boxShadow: `inset 0 0 0 1px ${result.color}55, 0 0 30px -8px ${result.color}` }}>
              <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: result.color }}>{result.ray} · {result.master}</p>
              <p className="mt-1 font-display text-xl font-semibold">{result.name}</p>
              <p className="text-sm text-muted-foreground">{result.quality}</p>
              <p className="mt-3 leading-relaxed text-foreground/90">{result.message}</p>
              <p className="mt-3 font-display text-gold">{result.decree}</p>
              <div className="mt-3"><CopyButton text={result.decree} /></div>
            </motion.div>
          ) : (
            <p className="text-sm text-muted-foreground">{spinning ? 'A roda está girando…' : 'O resultado aparecerá aqui.'}</p>
          )}
        </AnimatePresence>
      </div>

      <button type="button" onClick={spin} disabled={spinning} className="btn-gold mt-4 inline-flex items-center gap-2 rounded-full px-6 py-3 font-semibold disabled:opacity-70">
        <RotateCw className={`h-4 w-4 ${spinning ? 'animate-spin' : ''}`} /> Girar a Roda
      </button>
    </div>
  )
}
