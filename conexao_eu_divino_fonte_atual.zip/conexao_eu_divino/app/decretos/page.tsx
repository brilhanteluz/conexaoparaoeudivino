import type { Metadata } from 'next'
import { Flame, Mic, Eye, Heart, Repeat } from 'lucide-react'
import { PageHero, SectionTitle } from '@/components/page-hero'
import { Reveal } from '@/components/reveal'
import { FUNDAMENTAL_DECREES } from '@/lib/data/decretos'
import { DecreeList } from './_components/decree-list'

export const metadata: Metadata = {
  title: 'Decretos & Afirmações do Eu Sou',
  description: 'Decretos do Eu Sou para Chama Violeta, proteção, amor, cura, abundância e ascensão, com contador pessoal e favoritos.',
}

const KEYS = [
  { icon: Mic, t: 'Voz', d: 'Fale em voz alta e com firmeza. A palavra falada ancora a luz no plano físico.' },
  { icon: Eye, t: 'Visualização', d: 'Veja a luz agindo enquanto decreta: chamas, raios e esferas de luz.' },
  { icon: Heart, t: 'Sentimento', d: 'Decrete com amor e gratidão. O sentimento é o combustível da manifestação.' },
  { icon: Repeat, t: 'Repetição', d: 'Repita 3, 9, 33 ou 108 vezes. O ritmo acumula energia espiritual.' },
]

export default function DecretosPage() {
  return (
    <>
      <PageHero
        icon={Flame}
        eyebrow="A Ciência da Palavra Falada"
        title="Decretos & Afirmações"
        description="O decreto é a forma mais dinâmica de oração: em nome da sua Presença Eu Sou, você comanda a Luz de Deus a se manifestar em sua vida e no mundo."
      />

      <section className="mx-auto max-w-[1200px] px-6 pb-12">
        <Reveal>
          <div className="glass rounded-2xl p-8 md:p-10">
            <h2 className="font-display text-2xl font-semibold">O poder dos Decretos do Eu Sou</h2>
            <p className="mt-4 leading-relaxed text-foreground/85">
              Toda energia que flui da sua Presença Eu Sou é neutra e pura. É a sua atenção, seus pensamentos, sentimentos e palavras que a qualificam. Ao dizer “Eu Sou”, você usa o nome de Deus e imprime uma intenção nessa energia. Por isso, os Mestres ensinam: <strong className="text-primary">tudo o que você afirma depois de “Eu Sou”, você se torna</strong>. Os decretos são afirmações conscientes e rítmicas que direcionam a luz para a transmutação, a proteção, a cura e a iluminação.
            </p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {KEYS.map((k) => {
                const Icon = k.icon
                return (
                  <div key={k.t} className="rounded-lg bg-background/40 p-4 shadow-md">
                    <Icon className="mb-2 h-5 w-5 text-primary" />
                    <h3 className="font-display font-semibold">{k.t}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{k.d}</p>
                  </div>
                )
              })}
            </div>
          </div>
        </Reveal>
      </section>

      <section className="bg-accent/10 py-16">
        <div className="mx-auto max-w-[1200px] px-6">
          <SectionTitle eyebrow="Em destaque" title="Os 7 Decretos Fundamentais do Eu Sou" description="Um decreto para cada um dos sete raios — uma prática completa para equilibrar todas as virtudes divinas." />
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {FUNDAMENTAL_DECREES.map((f, i: number) => (
              <Reveal key={f.ray} delay={i * 0.06} className={i === 6 ? 'md:col-span-2 lg:col-span-1' : ''}>
                <div className="glass glass-hover relative h-full overflow-hidden rounded-xl p-6">
                  <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full blur-2xl" style={{ background: `${f.color}55` }} />
                  <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: f.color }}>{f.ray} · {f.flame}</p>
                  <p className="mt-3 font-display text-base leading-relaxed text-foreground">{f.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1200px] px-6 py-20">
        <SectionTitle eyebrow="Biblioteca" title="Decretos por Tema" description="Filtre por chama ou intenção, copie, favorite e registre cada decreto pronunciado." />
        <DecreeList />
      </section>
    </>
  )
}
