'use client'

import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Heart, Flame, Filter, Star } from 'lucide-react'
import { toast } from 'sonner'
import { CopyButton } from '@/components/copy-button'
import { cn } from '@/lib/utils'
import { DECREES, DECREE_CATEGORIES, type Decree, type DecreeCategory } from '@/lib/data/decretos'

const FAV_KEY = 'ced_favoritos'
const COUNT_KEY = 'ced_contagens'

type FilterId = 'todos' | 'favoritos' | DecreeCategory

function readJSON<T>(key: string, fallback: T): T {
  try {
    const raw = window?.localStorage?.getItem?.(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

export function DecreeList() {
  const [filter, setFilter] = useState<FilterId>('todos')
  const [favs, setFavs] = useState<string[]>([])
  const [counts, setCounts] = useState<Record<string, number>>({})

  useEffect(() => {
    setFavs(readJSON<string[]>(FAV_KEY, []))
    setCounts(readJSON<Record<string, number>>(COUNT_KEY, {}))
  }, [])

  const total = useMemo(() => Object.values(counts ?? {}).reduce((a: number, b: number) => a + (b ?? 0), 0), [counts])

  const list = useMemo(() => {
    if (filter === 'todos') return DECREES
    if (filter === 'favoritos') return DECREES.filter((d: Decree) => favs?.includes?.(d.id))
    return DECREES.filter((d: Decree) => d.category === filter)
  }, [filter, favs])

  const toggleFav = (id: string) => {
    setFavs((prev: string[]) => {
      const has = prev?.includes?.(id)
      const next = has ? prev.filter((x: string) => x !== id) : [...(prev ?? []), id]
      try { window.localStorage.setItem(FAV_KEY, JSON.stringify(next)) } catch (e) { console.error(e) }
      toast.success(has ? 'Removido dos favoritos' : 'Adicionado aos favoritos ✨')
      return next
    })
  }

  const pronounce = (id: string) => {
    setCounts((prev: Record<string, number>) => {
      const next = { ...(prev ?? {}), [id]: (prev?.[id] ?? 0) + 1 }
      try { window.localStorage.setItem(COUNT_KEY, JSON.stringify(next)) } catch (e) { console.error(e) }
      return next
    })
    fetch('/api/decree-counter', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ amount: 1 }) })
      .catch((e: unknown) => console.error('Erro ao somar ao contador coletivo:', e))
    toast.success('Decreto registrado. Sua Luz foi somada à corrente coletiva!')
  }

  const filters: { id: FilterId; label: string }[] = [
    { id: 'todos', label: 'Todos' },
    ...DECREE_CATEGORIES,
    { id: 'favoritos', label: 'Favoritos' },
  ]

  return (
    <div>
      <div className="glass mb-8 flex flex-col items-center justify-between gap-4 rounded-xl p-5 sm:flex-row">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/15 text-primary"><Star className="h-6 w-6" /></div>
          <div>
            <p className="text-xs uppercase tracking-widest text-muted-foreground">Seu contador pessoal</p>
            <p className="font-display text-2xl font-bold text-gold tabular-nums">{total} decretos pronunciados</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">{favs?.length ?? 0} favorito(s) salvo(s) neste dispositivo</p>
      </div>

      <div className="mb-8 flex flex-wrap items-center justify-center gap-2" role="tablist" aria-label="Filtrar decretos">
        <Filter className="mr-1 h-4 w-4 text-muted-foreground" />
        {filters.map((f) => (
          <button
            key={f.id}
            type="button"
            role="tab"
            aria-selected={filter === f.id}
            onClick={() => setFilter(f.id)}
            className={cn(
              'rounded-full px-4 py-2 text-sm font-medium transition-all',
              filter === f.id ? 'btn-gold' : 'bg-secondary/25 text-foreground/85 hover:bg-secondary/45'
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <div className="glass rounded-xl p-10 text-center text-muted-foreground">
          <Heart className="mx-auto mb-3 h-8 w-8 text-primary" />
          Você ainda não marcou nenhum decreto como favorito.
        </div>
      ) : (
        <motion.div layout className="grid gap-6 md:grid-cols-2">
          <AnimatePresence mode="popLayout">
            {list.map((d: Decree) => {
              const fav = favs?.includes?.(d.id) ?? false
              const cat = DECREE_CATEGORIES.find((c) => c.id === d.category)?.label ?? ''
              return (
                <motion.article
                  key={d.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.35 }}
                  className="glass glass-hover flex flex-col rounded-xl p-6"
                >
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <div>
                      <span className="rounded-full bg-accent/60 px-3 py-1 text-xs font-semibold text-accent-foreground">{cat}</span>
                      <h3 className="mt-3 font-display text-xl font-semibold text-foreground">{d.title}</h3>
                      <p className="text-xs text-muted-foreground">{d.master}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => toggleFav(d.id)}
                      aria-label={fav ? 'Remover dos favoritos' : 'Marcar como favorito'}
                      aria-pressed={fav}
                      className="rounded-full bg-secondary/25 p-2 transition-colors hover:bg-secondary/50"
                    >
                      <Heart className={cn('h-5 w-5', fav ? 'fill-primary text-primary' : 'text-foreground/70')} />
                    </button>
                  </div>
                  <p className="flex-1 whitespace-pre-line font-display text-[15px] leading-relaxed text-foreground/90">{d.text}</p>
                  <div className="mt-5 flex flex-wrap items-center gap-2">
                    <CopyButton text={`${d.title}\n\n${d.text}`} />
                    <button
                      type="button"
                      onClick={() => pronounce(d.id)}
                      className="btn-gold inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-semibold"
                    >
                      <Flame className="h-4 w-4" /> Pronunciei este Decreto
                    </button>
                    <span className="ml-auto rounded-full bg-primary/15 px-3 py-1 text-xs font-semibold text-primary tabular-nums">
                      {counts?.[d.id] ?? 0}x
                    </span>
                  </div>
                </motion.article>
              )
            })}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  )
}
