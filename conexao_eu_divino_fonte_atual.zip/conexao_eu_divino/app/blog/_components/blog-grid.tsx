'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Clock, ArrowRight, Tag } from 'lucide-react'
import { cn } from '@/lib/utils'
import { SafeDate } from '@/components/safe-format'
import { BLOG_CATEGORIES, type BlogPost, type BlogCategory } from '@/lib/data/blog-posts'

export function BlogGrid({ posts }: { posts: BlogPost[] }) {
  const [cat, setCat] = useState<BlogCategory | 'Todos'>('Todos')
  const list = (posts ?? []).filter((p: BlogPost) => cat === 'Todos' || p.category === cat)

  return (
    <div>
      <div className="mb-10 flex flex-wrap items-center justify-center gap-2" role="tablist" aria-label="Categorias">
        <Tag className="mr-1 h-4 w-4 text-muted-foreground" />
        {(['Todos', ...BLOG_CATEGORIES] as (BlogCategory | 'Todos')[]).map((c) => (
          <button
            key={c}
            type="button"
            role="tab"
            aria-selected={cat === c}
            onClick={() => setCat(c)}
            className={cn('rounded-full px-4 py-2 text-sm font-medium transition-all', cat === c ? 'btn-gold' : 'bg-secondary/25 text-foreground/85 hover:bg-secondary/45')}
          >
            {c}
          </button>
        ))}
      </div>

      <motion.div layout className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {list.map((p: BlogPost) => (
            <motion.div key={p.slug} layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ duration: 0.35 }}>
              <Link href={`/blog/${p.slug}`} className="glass glass-hover group flex h-full flex-col overflow-hidden rounded-xl">
                <div className="relative aspect-video bg-muted">
                  <Image src={p.image} alt={p.title} fill className="object-cover transition-transform duration-700 group-hover:scale-105" sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw" />
                  <span className="absolute left-3 top-3 rounded-full bg-background/80 px-3 py-1 text-xs font-semibold text-primary backdrop-blur">{p.category}</span>
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <h2 className="font-display text-lg font-semibold leading-snug group-hover:text-primary">{p.title}</h2>
                  <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{p.excerpt}</p>
                  <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" /> {p.readTime} · <SafeDate date={p.date} options={{ day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' }} locale="pt-BR" /></span>
                    <ArrowRight className="h-4 w-4 text-primary transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  )
}
