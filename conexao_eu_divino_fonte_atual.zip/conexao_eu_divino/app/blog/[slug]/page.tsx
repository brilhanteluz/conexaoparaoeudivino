import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import { ArrowLeft, Clock, User, Quote } from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { ShareButtons } from '@/components/share-buttons'
import { SafeDate } from '@/components/safe-format'
import { BLOG_POSTS, getPost } from '@/lib/data/blog-posts'

export function generateStaticParams() {
  return BLOG_POSTS.map((p) => ({ slug: p.slug }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const p = getPost(slug)
  return {
    title: p?.title ?? 'Artigo',
    description: p?.excerpt ?? '',
    openGraph: p ? { title: p.title, description: p.excerpt, images: [p.image] } : undefined,
  }
}

export default async function PostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const post = getPost(slug)
  if (!post) notFound()
  const related = BLOG_POSTS.filter((p) => p.slug !== post.slug).slice(0, 3)

  return (
    <article className="mx-auto max-w-[1200px] px-6 py-12">
      <Link href="/blog" className="mb-8 inline-flex items-center gap-2 rounded-md bg-secondary/25 px-4 py-2 text-sm hover:bg-secondary/45 hover:text-primary">
        <ArrowLeft className="h-4 w-4" /> Voltar ao Blog
      </Link>

      <Reveal className="mx-auto max-w-3xl text-center">
        <span className="rounded-full bg-primary/15 px-3 py-1 text-xs font-semibold text-primary">{post.category}</span>
        <h1 className="mt-4 font-display text-3xl font-semibold leading-tight tracking-tight text-gold md:text-5xl">{post.title}</h1>
        <p className="mt-4 text-lg text-foreground/80">{post.excerpt}</p>
        <div className="mt-5 flex flex-wrap items-center justify-center gap-4 text-sm text-muted-foreground">
          <span className="inline-flex items-center gap-1"><User className="h-4 w-4" /> {post.author}</span>
          <span className="inline-flex items-center gap-1"><Clock className="h-4 w-4" /> {post.readTime} de leitura</span>
          <SafeDate date={post.date} options={{ day: '2-digit', month: 'long', year: 'numeric', timeZone: 'UTC' }} locale="pt-BR" />
        </div>
      </Reveal>

      <Reveal delay={0.1} className="mx-auto mt-10 max-w-4xl">
        <div className="relative aspect-video overflow-hidden rounded-xl bg-muted shadow-2xl">
          <Image src={post.image} alt={post.title} fill className="object-cover" sizes="(max-width: 1024px) 100vw, 900px" priority />
        </div>
      </Reveal>

      <div className="glass mx-auto mt-10 max-w-3xl rounded-2xl p-6 md:p-10">
        <div className="space-y-5 text-[17px] leading-relaxed text-foreground/90">
          {post.content.map((b, i: number) => {
            if (b.type === 'h2') return <h2 key={i} className="pt-4 font-display text-2xl font-semibold text-foreground">{b.text}</h2>
            if (b.type === 'quote')
              return (
                <blockquote key={i} className="relative rounded-lg bg-accent/40 p-6 font-display text-lg italic text-gold">
                  <Quote className="mb-2 h-5 w-5 text-primary/70" />
                  {b.text}
                </blockquote>
              )
            return <p key={i}>{b.text}</p>
          })}
        </div>
        <div className="gold-divider my-8" />
        <ShareButtons title={post.title} path={`/blog/${post.slug}`} label="Compartilhar" />
      </div>

      <section className="mt-16">
        <h2 className="mb-6 text-center font-display text-2xl font-semibold">Continue lendo</h2>
        <div className="grid gap-6 md:grid-cols-3">
          {related.map((p) => (
            <Link key={p.slug} href={`/blog/${p.slug}`} className="glass glass-hover group overflow-hidden rounded-xl">
              <div className="relative aspect-video bg-muted">
                <Image src={p.image} alt={p.title} fill className="object-cover" sizes="33vw" />
              </div>
              <div className="p-4">
                <p className="text-xs text-primary">{p.category}</p>
                <p className="mt-1 font-display font-semibold group-hover:text-primary">{p.title}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </article>
  )
}
