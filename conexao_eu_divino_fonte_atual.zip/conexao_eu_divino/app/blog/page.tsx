import type { Metadata } from 'next'
import { BookOpen } from 'lucide-react'
import { PageHero } from '@/components/page-hero'
import { BLOG_POSTS } from '@/lib/data/blog-posts'
import { BlogGrid } from './_components/blog-grid'

export const metadata: Metadata = {
  title: 'Blog — Mensagens dos Mestres',
  description: 'Ensinamentos, mensagens canalizadas, práticas e reflexões sobre a Presença Eu Sou e a Grande Fraternidade Branca.',
}

export default function BlogPage() {
  return (
    <>
      <PageHero
        icon={BookOpen}
        eyebrow="Blog"
        title="Mensagens dos Mestres"
        description="Ensinamentos, mensagens inspiradas, práticas e reflexões para nutrir sua alma e iluminar sua jornada de volta à Presença Eu Sou."
      />
      <section className="mx-auto max-w-[1200px] px-6">
        <BlogGrid posts={BLOG_POSTS} />
      </section>
    </>
  )
}
