import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const rows = await prisma.lightRequest.findMany({
      orderBy: { createdAt: 'desc' },
      take: 12,
      select: { id: true, name: true, intention: true, createdAt: true },
    })
    return NextResponse.json({ requests: rows ?? [] })
  } catch (err) {
    console.error('Erro ao listar pedidos:', err)
    return NextResponse.json({ requests: [] })
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { name?: string; intention?: string }
    const name = String(body?.name ?? '').trim().slice(0, 60)
    const intention = String(body?.intention ?? '').trim().slice(0, 500)
    if (name.length < 2 || intention.length < 5) {
      return NextResponse.json({ error: 'Informe seu nome e uma intenção com pelo menos 5 caracteres.' }, { status: 400 })
    }
    const row = await prisma.lightRequest.create({ data: { name, intention } })
    return NextResponse.json({ request: row }, { status: 201 })
  } catch (err) {
    console.error('Erro ao salvar pedido:', err)
    return NextResponse.json({ error: 'Não foi possível enviar seu pedido agora.' }, { status: 500 })
  }
}
