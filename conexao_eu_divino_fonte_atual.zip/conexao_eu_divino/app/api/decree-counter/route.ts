import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

const ID = 'global'

export async function GET() {
  try {
    const row = await prisma.decreeCounter.upsert({
      where: { id: ID },
      update: {},
      create: { id: ID, count: BigInt(144000) },
    })
    return NextResponse.json({ count: Number(row?.count ?? 144000) })
  } catch (err) {
    console.error('Erro ao ler contador:', err)
    return NextResponse.json({ count: 144000 }, { status: 200 })
  }
}

export async function POST(req: Request) {
  try {
    let amount = 1
    try {
      const body = (await req.json()) as { amount?: number }
      const n = Number(body?.amount ?? 1)
      amount = Number.isFinite(n) ? Math.min(Math.max(Math.floor(n), 1), 108) : 1
    } catch {
      amount = 1
    }
    const row = await prisma.decreeCounter.upsert({
      where: { id: ID },
      update: { count: { increment: BigInt(amount) } },
      create: { id: ID, count: BigInt(144000 + amount) },
    })
    return NextResponse.json({ count: Number(row?.count ?? 144000) })
  } catch (err) {
    console.error('Erro ao incrementar contador:', err)
    return NextResponse.json({ error: 'Não foi possível registrar agora.' }, { status: 500 })
  }
}
