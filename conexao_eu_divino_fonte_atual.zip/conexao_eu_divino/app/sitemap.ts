import type { MetadataRoute } from 'next'
import { headers } from 'next/headers'
import { MASTERS } from '@/lib/data/mestres'
import { BLOG_POSTS } from '@/lib/data/blog-posts'

export const dynamic = 'force-dynamic'

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const h = await headers()
  const host = h?.get?.('x-forwarded-host') ?? h?.get?.('host') ?? 'localhost:3000'
  const base = `https://${host}`
  const pages = ['', '/eu-sou', '/mestres', '/decretos', '/meditacoes', '/blog', '/comunidade', '/contato']
  return [
    ...pages.map((p: string) => ({ url: `${base}${p}` })),
    ...(MASTERS ?? []).map((m: { slug: string }) => ({ url: `${base}/mestres/${m?.slug}` })),
    ...(BLOG_POSTS ?? []).map((b: { slug: string }) => ({ url: `${base}/blog/${b?.slug}` })),
  ]
}
