import Image from 'next/image'
import Link from 'next/link'
import type { Metadata } from 'next'
import { Sun, Shield, Lightbulb, Heart, Flame, Wind, Eye, Hand, Moon, Sparkles, ArrowRight, User, Crown } from 'lucide-react'
import { PageHero, SectionTitle } from '@/components/page-hero'
import { Reveal } from '@/components/reveal'

export const metadata: Metadata = {
  title: 'A Divina Presença Eu Sou',
  description: 'Explicação completa sobre a Divina Presença Eu Sou, a Chama Trina, o Santo Ser Crístico e a Chama Violeta de Saint Germain.',
}

const TRINA = [
  {
    icon: Shield,
    name: 'Poder',
    color: '#3B82F6',
    plume: 'Pluma Azul — à esquerda',
    aspect: 'Deus Pai',
    text: 'O Poder divino é a força da fé, da vontade e da coragem. Ele nos dá firmeza para agir segundo o Plano Divino. Sem amor e sabedoria, o poder se torna tirania; equilibrado, torna-se proteção e liderança servidora.',
  },
  {
    icon: Lightbulb,
    name: 'Sabedoria',
    color: '#FFD700',
    plume: 'Pluma Dourada — ao centro',
    aspect: 'Deus Filho (o Cristo)',
    text: 'A Sabedoria é a iluminação da mente de Cristo: o discernimento que sabe como e quando usar o poder e o amor. Sem os outros aspectos, torna-se orgulho intelectual; equilibrada, é compreensão profunda da vida.',
  },
  {
    icon: Heart,
    name: 'Amor',
    color: '#F472B6',
    plume: 'Pluma Rosa — à direita',
    aspect: 'Deus Espírito Santo',
    text: 'O Amor é a força que une, cura e cria. É a compaixão, a beleza e a gratidão. Sem poder e sabedoria, o amor se torna fraqueza ou sentimentalismo; equilibrado, é a força mais poderosa do universo.',
  },
]

const STEPS = [
  { icon: Moon, title: 'Silencie', text: 'Reserve alguns minutos diários de quietude. A Presença fala no silêncio, não no ruído da mente.' },
  { icon: Eye, title: 'Visualize', text: 'Contemple acima de você um sol radiante — sua Presença Eu Sou — ligado ao seu coração pelo Cordão de Cristal.' },
  { icon: Heart, title: 'Sinta a Chama Trina', text: 'Leve a atenção ao centro do peito e sinta as três plumas: azul, dourada e rosa. Veja-as crescer com cada respiração.' },
  { icon: Wind, title: 'Decrete em voz alta', text: 'Use afirmações começando com “Eu Sou”. A palavra falada ancora a luz no mundo físico.' },
  { icon: Flame, title: 'Use a Chama Violeta', text: 'Transmute diariamente os obstáculos que separam sua consciência exterior da sua Presença.' },
  { icon: Hand, title: 'Sirva com amor', text: 'Toda ação feita com amor é uma ponte para a Presença. O serviço é meditação em movimento.' },
]

const AFFIRMATIONS = [
  'Eu Sou o Que Eu Sou.',
  'Eu Sou a Ressurreição e a Vida.',
  'Eu Sou a Luz que ilumina todo homem que vem ao mundo.',
  'Eu Sou a Presença de Deus em ação em mim agora.',
  'Eu Sou a Perfeição Divina manifesta.',
  'Eu Sou o Caminho, a Verdade e a Vida.',
  'Eu Sou a Opulência de Deus em minha vida.',
  'Eu Sou a Vitória de Deus em cada situação.',
  'Eu Sou a Paz que ultrapassa todo entendimento.',
]

export default function EuSouPage() {
  return (
    <>
      <PageHero
        icon={Sun}
        eyebrow="O coração do ensinamento"
        title="A Divina Presença Eu Sou"
        description="Descubra a verdade mais libertadora de todas: Deus habita em você, individualizado como a sua Presença Eu Sou — perfeita, eterna e sempre disponível."
      />

      {/* O que é */}
      <section className="mx-auto grid max-w-[1200px] items-center gap-10 px-6 py-16 lg:grid-cols-2">
        <Reveal>
          <div className="relative aspect-[4/3] overflow-hidden rounded-xl bg-muted shadow-2xl">
            <Image src="https://cdn.abacus.ai/images/75cead93-ae73-4f54-afe7-96e7a8b02261.png" alt="Sol dourado da Presença Eu Sou sobre uma pessoa em meditação" fill className="object-cover" sizes="(max-width: 1024px) 100vw, 50vw" />
          </div>
        </Reveal>
        <Reveal delay={0.15}>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-primary/80">O que é</p>
          <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight md:text-4xl">Deus individualizado em você</h2>
          <div className="mt-6 space-y-4 leading-relaxed text-foreground/85">
            <p>A <strong className="text-primary">Divina Presença Eu Sou</strong> é a individualização de Deus para cada alma. Ela é o seu Eu Real, o seu Ser Divino original, criado à imagem e semelhança de Deus e jamais tocado por qualquer imperfeição humana.</p>
            <p>Segundo os ensinamentos dos Mestres Ascencionados, ela reside em uma dimensão de luz pura, logo acima de você, e envia continuamente sua energia vital através de um fio luminoso — o <em>Cordão de Cristal</em> — que se ancora no seu coração como a Chama Trina.</p>
            <p>Ao redor da Presença está o <em>Corpo Causal</em>: esferas concêntricas de luz colorida onde se acumula todo o bem que você realizou em todas as suas vidas — seu verdadeiro “tesouro no céu”.</p>
            <p>Toda a vida que anima seu corpo, cada batimento do coração e cada pensamento são energia emprestada da sua Presença. Reconhecê-la é o primeiro passo para reencontrar sua origem divina.</p>
          </div>
        </Reveal>
      </section>

      {/* Significado */}
      <section className="bg-accent/10 py-16">
        <div className="mx-auto max-w-[1200px] px-6">
          <SectionTitle eyebrow="O Nome Sagrado" title="O que significa “EU SOU”" />
          <div className="grid gap-6 md:grid-cols-3">
            {[
              { t: 'A revelação a Moisés', d: 'Diante da sarça ardente, Deus revelou Seu nome: “EU SOU O QUE EU SOU” (Êxodo 3:14). É o nome de Deus como existência pura, presente e eterna.' },
              { t: 'A palavra criadora', d: 'Toda vez que você diz “eu sou”, invoca o nome de Deus e qualifica a energia divina. “Eu sou fraco” cria fraqueza; “Eu Sou a Luz” manifesta luz.' },
              { t: 'O Cristo interior', d: 'Jesus usou o Eu Sou para revelar sua união com o Pai: “Eu Sou a Luz do mundo”, “Eu Sou a Ressurreição e a Vida”. Ele falava a partir da Presença.' },
            ].map((c, i: number) => (
              <Reveal key={c.t} delay={i * 0.1}>
                <div className="glass glass-hover h-full rounded-xl p-6">
                  <Sparkles className="mb-3 h-6 w-6 text-primary" />
                  <h3 className="font-display text-lg font-semibold">{c.t}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{c.d}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Diagrama */}
      <section className="mx-auto max-w-[1200px] px-6 py-20">
        <SectionTitle eyebrow="Diagrama" title="A Carta da Presença Eu Sou" description="As três figuras do diagrama sagrado representam a ponte entre o Espírito e a matéria." />
        <Reveal>
          <div className="glass relative mx-auto max-w-2xl overflow-hidden rounded-2xl p-6 md:p-10">
            {/* Tubo de Luz */}
            <div className="pointer-events-none absolute left-1/2 top-[40%] h-[60%] w-44 -translate-x-1/2 rounded-t-full bg-gradient-to-b from-white/0 via-white/5 to-white/10" />
            <div className="pointer-events-none absolute left-1/2 top-24 h-[75%] w-px -translate-x-1/2 bg-gradient-to-b from-primary via-primary/60 to-secondary" />

            <div className="relative flex flex-col items-center gap-8">
              {/* Presença */}
              <div className="flex flex-col items-center text-center">
                <div className="relative flex h-40 w-40 items-center justify-center">
                  {['#A855F7', '#22C55E', '#F8FAFC', '#F472B6', '#FFD700', '#3B82F6'].map((c: string, i: number) => (
                    <span key={c} className="absolute rounded-full border-2" style={{ inset: `${i * 10}px`, borderColor: c, opacity: 0.7 }} />
                  ))}
                  <div className="pulse-glow relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-yellow-200 to-primary">
                    <Crown className="h-8 w-8 text-primary-foreground" />
                  </div>
                </div>
                <h3 className="mt-3 font-display text-xl font-semibold text-gold">Eu Sou o Que Eu Sou</h3>
                <p className="mt-1 max-w-md text-sm text-muted-foreground">A Presença Eu Sou cercada pelo Corpo Causal — as sete esferas de luz dos raios divinos. Sua fonte de vida, energia e bem.</p>
              </div>

              {/* Santo Ser Crístico */}
              <div className="flex flex-col items-center text-center">
                <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-b from-yellow-100/80 to-primary/70 shadow-[0_0_40px_rgba(255,215,0,0.45)]">
                  <Sun className="h-10 w-10 text-primary-foreground" />
                </div>
                <h3 className="mt-3 font-display text-xl font-semibold text-foreground">Santo Ser Crístico</h3>
                <p className="mt-1 max-w-md text-sm text-muted-foreground">O mediador e instrutor interior, o Cristo pessoal que traduz a luz da Presença para a consciência humana. De seu coração desce o Cordão de Cristal.</p>
              </div>

              {/* Ser humano */}
              <div className="flex flex-col items-center text-center">
                <div className="relative flex h-28 w-24 items-end justify-center">
                  <div className="flame-flicker absolute inset-x-0 bottom-0 h-full rounded-t-full bg-gradient-to-t from-secondary via-secondary/70 to-transparent blur-[2px]" />
                  <User className="relative mb-3 h-12 w-12 text-foreground" />
                  <div className="absolute bottom-7 flex gap-0.5">
                    <span className="h-3 w-1 rounded-full bg-blue-400" />
                    <span className="h-4 w-1 rounded-full bg-yellow-300" />
                    <span className="h-3 w-1 rounded-full bg-pink-400" />
                  </div>
                </div>
                <h3 className="mt-3 font-display text-xl font-semibold text-foreground">O Ser Humano</h3>
                <p className="mt-1 max-w-md text-sm text-muted-foreground">A alma em evolução, com a Chama Trina no coração, envolta pela Chama Violeta e protegida pelo Tubo de Luz branca que desce da Presença.</p>
              </div>
            </div>
          </div>
        </Reveal>
      </section>

      {/* Chama Trina */}
      <section className="bg-accent/10 py-20">
        <div className="mx-auto max-w-[1200px] px-6">
          <SectionTitle eyebrow="A centelha divina" title="A Chama Trina" description="No altar secreto do coração arde a Chama Trina: três plumas que representam os três aspectos de Deus. Nosso crescimento espiritual depende do seu equilíbrio." />
          <div className="grid gap-6 md:grid-cols-3">
            {TRINA.map((t, i: number) => {
              const Icon = t.icon
              return (
                <Reveal key={t.name} delay={i * 0.1}>
                  <div className="glass glass-hover relative h-full overflow-hidden rounded-xl p-7">
                    <div className="absolute inset-x-0 top-0 h-1" style={{ background: t.color }} />
                    <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full" style={{ background: `${t.color}26`, color: t.color, boxShadow: `0 0 30px ${t.color}55` }}>
                      <Icon className="h-7 w-7" />
                    </div>
                    <h3 className="font-display text-2xl font-semibold" style={{ color: t.color }}>{t.name}</h3>
                    <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{t.plume} · {t.aspect}</p>
                    <p className="mt-4 text-sm leading-relaxed text-foreground/85">{t.text}</p>
                  </div>
                </Reveal>
              )
            })}
          </div>
        </div>
      </section>

      {/* Como se conectar */}
      <section className="mx-auto max-w-[1200px] px-6 py-20">
        <SectionTitle eyebrow="Prática" title="Como se conectar com sua Presença Eu Sou" description="Seis passos simples para cultivar, dia após dia, uma relação viva com o seu Eu Divino." />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {STEPS.map((s, i: number) => {
            const Icon = s.icon
            return (
              <Reveal key={s.title} delay={i * 0.07}>
                <div className="glass glass-hover flex h-full gap-4 rounded-xl p-6">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/15 font-display font-bold text-primary">{i + 1}</div>
                  <div>
                    <h3 className="flex items-center gap-2 font-display text-lg font-semibold"><Icon className="h-4 w-4 text-primary" /> {s.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.text}</p>
                  </div>
                </div>
              </Reveal>
            )
          })}
        </div>
      </section>

      {/* Afirmações */}
      <section className="py-16">
        <div className="mx-auto max-w-[1200px] px-6">
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-accent via-card to-secondary/60 p-8 shadow-2xl md:p-14">
            <SectionTitle eyebrow="Afirmações" title="Afirmações do Eu Sou" description="Pronuncie-as lentamente, sentindo cada palavra vibrar no coração." />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {AFFIRMATIONS.map((a: string, i: number) => (
                <Reveal key={a} delay={i * 0.05}>
                  <div className="flex h-full items-center gap-3 rounded-lg bg-background/40 p-5 shadow-lg backdrop-blur transition-all hover:bg-background/60 hover:shadow-[0_0_24px_rgba(212,175,55,0.35)]">
                    <Sparkles className="h-5 w-5 shrink-0 text-primary" />
                    <p className="font-display text-base text-gold">{a}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Chama Violeta */}
      <section className="mx-auto grid max-w-[1200px] items-center gap-10 px-6 py-20 lg:grid-cols-5">
        <Reveal className="lg:col-span-3">
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-primary/80">O 7º Raio</p>
          <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight md:text-4xl">A Chama Violeta e Saint Germain</h2>
          <div className="mt-6 space-y-4 leading-relaxed text-foreground/85">
            <p><strong className="text-foreground">O que é:</strong> a Chama Violeta é a energia espiritual do Sétimo Raio — a frequência da liberdade, da misericórdia, do perdão e da transmutação. Ela dissolve os registros de energia mal qualificada (carma) e devolve essa energia ao seu estado original de pureza.</p>
            <p><strong className="text-foreground">Saint Germain:</strong> hierarca da Era de Aquário, ele obteve da Lei Cósmica a permissão de liberar amplamente o conhecimento da Chama Violeta à humanidade no século XX, como ferramenta essencial para a Idade de Ouro.</p>
            <p><strong className="text-foreground">Como usar:</strong> conecte-se com sua Presença, visualize chamas violetas subindo dos pés à cabeça e decrete em voz alta, com ritmo e sentimento — por exemplo: <em className="text-primary">“Eu Sou um ser de Fogo Violeta, Eu Sou a pureza que Deus deseja!”</em> Comece com 5 a 15 minutos diários e envie a Chama também para sua família, sua cidade e o planeta.</p>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/decretos" className="btn-gold inline-flex items-center gap-2 rounded-full px-6 py-3 font-semibold"><Flame className="h-4 w-4" /> Decretos de Chama Violeta</Link>
            <Link href="/meditacoes" className="glass inline-flex items-center gap-2 rounded-full px-6 py-3 font-semibold hover:text-primary">Meditação guiada <ArrowRight className="h-4 w-4" /></Link>
          </div>
        </Reveal>
        <Reveal delay={0.15} className="lg:col-span-2">
          <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-muted shadow-[0_0_60px_rgba(168,85,247,0.35)]">
            <Image src="https://cdn.abacus.ai/images/fd0e8833-6550-4018-9b85-1b0daa882fce.png" alt="Mestre Saint Germain envolto na Chama Violeta" fill className="object-cover" sizes="(max-width: 1024px) 100vw, 40vw" />
          </div>
        </Reveal>
      </section>
    </>
  )
}
